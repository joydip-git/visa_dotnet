﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionDemo
{
    class Vehicle
    {
        private int _currentSpeed;
        public const int MAXIMUMSPEED = 100;

        public int CurrentSpeed
        {
            get { return _currentSpeed; }
            set
            {
                if (value > MAXIMUMSPEED)
                {
                    throw new SpeedOverLimitException($"can't cross maximum speed of {MAXIMUMSPEED}");
                }
                else
                    _currentSpeed = value;
            }
        }
        public void IncreaseSpeed(int speed)
        {
            if (_currentSpeed + speed > MAXIMUMSPEED)
            {
                throw new SpeedOverLimitException($"can't cross maximum speed of {MAXIMUMSPEED}");
            }
            else
                _currentSpeed += speed;
        }
    }
}
