﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionDemo
{
    class SpeedOverLimitException:ApplicationException
    {
        private string _errorMessage;
        public SpeedOverLimitException() { }
        public SpeedOverLimitException(string message)
        {
            _errorMessage = message;
        }
        public override string Message => _errorMessage;
    }
}
