﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionDemo
{
    class InappropriateAgeException:ApplicationException
    {
        //private string _errorMessage;
        public InappropriateAgeException() { }
        public InappropriateAgeException(string message):base(message)
        {
            //_errorMessage = message;
        }
        //public override string Message => _errorMessage;
    }
}
