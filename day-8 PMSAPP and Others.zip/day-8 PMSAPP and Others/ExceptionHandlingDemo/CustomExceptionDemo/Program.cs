﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionDemo
{
    class Program
    {
        static void CreateApplication()
        {
            DrivingLicenseForm drivingLicense = new DrivingLicenseForm();
            drivingLicense.Name = "Joydip";
            try
            {
                drivingLicense.Age = 17;
            }
            catch (InappropriateAgeException ex)
            {
                throw ex;
            }
        }
        static void IncreaseVehicleSpeed()
        {
            Vehicle vehicle = new Vehicle();
            try
            {
                vehicle.CurrentSpeed = 60;
                //vehicle.CurrentSpeed = 100;
                vehicle.IncreaseSpeed(30);
                vehicle.IncreaseSpeed(40);
            }
            catch (SpeedOverLimitException ex)
            {
                throw ex;
            }
        }
        static void Main()
        {
            try
            {
                //CreateApplication();
                IncreaseVehicleSpeed();
            }
            catch(SpeedOverLimitException ex)
            {
                PrintException(ex);
            }
            catch (InappropriateAgeException ex)
            {
                PrintException(ex);
            }
            catch (Exception ex)
            {
                PrintException(ex);
            }
        }
        private static void PrintException(Exception ex)
        {
            Console.WriteLine($"Exception Type: {ex.GetType().Name}");
            Console.WriteLine($"Message: {ex.Message} ");
            Console.WriteLine($"Method: {ex.TargetSite} ");
            Console.WriteLine($"Application: {ex.Source} ");
            Console.WriteLine($"Details: {ex.StackTrace} ");
        }
    }
}
