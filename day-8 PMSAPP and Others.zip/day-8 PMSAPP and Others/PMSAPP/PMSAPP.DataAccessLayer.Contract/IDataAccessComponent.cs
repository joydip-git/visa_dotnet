﻿using System.Collections.Generic;

namespace PMSAPP.DataAccessLayer.Contract
{
    public interface IDataAccessComponent<T> where T : class, new()
    {
        List<T> FetchAll();
        T Fetch(int id);
        int Insert(T newItem);
        int Delete(int id);
        int Modify(T newItem);
    }
}
