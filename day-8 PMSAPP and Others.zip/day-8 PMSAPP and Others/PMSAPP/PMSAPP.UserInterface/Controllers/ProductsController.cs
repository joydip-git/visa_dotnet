﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PMSAPP.UserInterface.Models;

namespace PMSAPP.UserInterface.Controllers
{
    public class ProductsController : Controller
    {
        // GET: Products
        public ActionResult Index()
        {
            return View();
        }
        public ViewResult GetProducts()
        {
            var products = ProductRepository.Products;
            //this.ViewBag.Data = products;
            this.ViewData["Data"] = products;
            return this.View();
        }
        [HttpGet]
        public ViewResult AddProduct()
        {
            return this.View();
        }
        [HttpPost]
        public ViewResult AddProduct(AddProductViewModel productVM)
        {
            //Product product = new Product
            //{
            //    Id = int.Parse(formCollection["txtId"])
            //};
            if (this.ModelState.IsValid)
            {
                var product = ProductRepository.Products.Where(p => p.Id == productVM.ProductModel.Id);
                if (product == null || product.Count() == 0)
                {
                    ProductRepository.Products.Add(productVM.ProductModel);
                    this.ViewBag.Status = true;
                }
                else
                {
                    this.ModelState.AddModelError("name exists", "product already exists");
                    this.ViewBag.Status = false;
                }
            }
            else
            {
                this.ViewBag.Status = false;
            }
            return this.View(productVM);
        }
        public ViewResult RemoveProduct()
        {
            return this.View();
        }
        public ViewResult UpdateProduct()
        {
            return this.View();
        }
    }
}