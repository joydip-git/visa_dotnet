﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMSAPP.UserInterface.Models
{
    public class AddProductViewModel
    {
        public Product ProductModel { get; set; }
    }
}