﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using PMSAPP.UserInterface.Models;

namespace PMSAPP.UserInterface.Models
{
    public static class ProductRepository
    {
        public readonly static List<Product> Products;
        static ProductRepository()
        {
            Products = new List<Product>
            {
                new Product{ Id=1, Name="Dell XPS 15", Price=67000, Description="new xps laptop from dell" },
                new Product{ Id=2, Name="The Alchemist", Price=599, Description="new book by " },
                new Product{ Id=3, Name="Dell XPS 15", Price=67000, Description="new xps laptop from dell" }
            };
        }
    }
}