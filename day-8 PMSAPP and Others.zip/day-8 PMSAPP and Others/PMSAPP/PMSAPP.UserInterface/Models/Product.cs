﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PMSAPP.UserInterface.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Product Name must be entered")]
        public string Name { get; set; }
        public decimal Price { get; set; }
        [Required(ErrorMessage = "Product description must be entered")]
        public string Description { get; set; }
    }
}