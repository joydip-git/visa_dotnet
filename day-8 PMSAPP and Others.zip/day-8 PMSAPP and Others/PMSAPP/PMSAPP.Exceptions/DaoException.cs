﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSAPP.Exceptions
{
    public class DaoException:ApplicationException
    {
        private string _errorMessage;
        private Exception _wrappedException;

        public DaoException()
        {

        }
        public DaoException(string message)
        {
            _errorMessage = message;
        }
        public DaoException(string message, Exception exception)
        {
            _errorMessage = message;
            _wrappedException = exception;
        }
        public override string Message => _errorMessage;
        public Exception WrappedException
        {
            get => _wrappedException;
        }
    }
}
