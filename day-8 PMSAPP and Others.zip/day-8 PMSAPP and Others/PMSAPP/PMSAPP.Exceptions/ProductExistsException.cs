﻿using System;

namespace PMSAPP.Exceptions
{
    public class ProductExistsException:ApplicationException
    {
        private string _errorMessage;
        public ProductExistsException()
        {

        }
        public ProductExistsException(string message)
        {
            _errorMessage = message;
        }
        public override string Message => _errorMessage;
    }
}
