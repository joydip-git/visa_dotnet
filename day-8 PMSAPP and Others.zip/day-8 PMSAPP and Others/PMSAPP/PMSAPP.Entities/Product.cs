﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSAPP.Entities
{
    public class Product:IComparable,IComparable<Product>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public override int GetHashCode()
        {
            return this.Id.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                if (obj is Product)
                {
                    Product other = obj as Product;
                    if (this == other)
                        return true;

                    if (!this.Id.Equals(other.Id))
                        return false;

                    if (!this.Name.Equals(other.Name))
                        return false;

                    if (!this.Description.Equals(other.Description))
                        return false;

                    if (!this.Price.Equals(other.Price))
                        return false;

                    return true;
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to Equals method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to Equals method");
        }

        public override string ToString()
        {
            return $"Name={this.Name},Id={this.Id}, Description = {this.Description} and Price = {this.Price}";
        }

        public int CompareTo(object obj)
        {
            if (obj != null)
            {
                if (obj is Product)
                {
                    Product other = obj as Product;
                    if (this == other)
                        return 0;

                    return this.Id.CompareTo(other.Id);
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }

        public int CompareTo(Product other)
        {
            if (other != null)
            {
                if (this == other)
                    return 0;

                return this.Id.CompareTo(other.Id);
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }
    }
}
