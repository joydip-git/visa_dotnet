﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSAPP.DependencyResolver
{
    public class Container
    {
        public void ResolveDependency(Type dependentType)
        {
            ICollection<DirectoryCatalog> directoryCatalogs = new List<DirectoryCatalog>();
            DirectoryCatalog directoryCatalog = new DirectoryCatalog(ConfigurationManager.AppSettings["dalPath"]);
            directoryCatalogs.Add(directoryCatalog);

            AggregateCatalog composablePartDefinitions = new AggregateCatalog(directoryCatalogs);
            CompositionContainer container = new CompositionContainer(composablePartDefinitions);

            container.ComposeParts();
        }
    }
}
