﻿using PMSAPP.DataAccessLayer.Contract;
using PMSAPP.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using PMSAPP.Repository;
using PMSAPP.Exceptions;

namespace PMSAPP.DataAccessLayer.Implementation
{
    //[Export(typeof(IDataAccessComponent<Product>))]
    //[PartCreationPolicy(CreationPolicy.NonShared)]
    public class ProductDataAccessComponent : IDataAccessComponent<Product>
    {
        public int Delete(int id)
        {
            int recordDeleted = 0;
            try
            {
                bool state = false;
                var allProducts = ProductRepository.Products;
                var products = allProducts.Where(p => p.Id == id);
                if (products != null && products.Count() > 0)
                {
                    state = allProducts.Remove(products.First());
                    if (state)
                        recordDeleted = 1;
                }
                else
                {
                    throw new ProductExistsException($"no product with given id {id} exists");
                }
                return recordDeleted;
            }
            catch (ProductExistsException ex)
            {
                throw WrapAndThrowException(ex);
            }
            catch (NullReferenceException ex)
            {
                throw WrapAndThrowException(ex);
            }
            catch (Exception ex)
            {
               throw WrapAndThrowException(ex);
            }
        }
        public Product Fetch(int id)
        {
            try
            {
                return null;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public List<Product> FetchAll()
        {
            try
            {
                return null;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public int Insert(Product newItem)
        {
            try
            {
                return 0;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public int Modify(Product newItem)
        {
            try
            {
                return 0;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        #region Helper Methods
        private static DaoException WrapAndThrowException(Exception ex)
        {
            DaoException daoEx = new DaoException(ex.Message, ex);
            throw daoEx;
        }
        #endregion
    }
}
