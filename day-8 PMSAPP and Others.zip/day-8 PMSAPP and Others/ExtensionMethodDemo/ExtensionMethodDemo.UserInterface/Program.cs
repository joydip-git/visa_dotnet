﻿using ExtensionMethodDemo.CalculationLibrary;
using ExtensionMethodDemo.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using static System.Collections.Generic.List<int>;

namespace ExtensionMethodDemo.UserInterface
{
    class Student
    {
        public int Id { get; set; }
        public static string ShoolName { get; private set; } = "abcd";
    }
    class Program
    {
        static void Main()
        {
            Calculation calculation = new Calculation();
            Console.WriteLine(calculation.Add(12, 13));
            ICalculation iCalculation = calculation;
            Console.WriteLine(iCalculation.Multiply(12, 13));
            //Console.WriteLine(calculation.Multiply(12,13));
            //Console.WriteLine(Extension.Multiply(calculation,12,13));

            List<int> numbers = new List<int> { 1, 2, 3, 4 };
            numbers
                .Where(num => num % 2 == 0)
                .OrderByDescending(num => num)
                .ToList<int>()
                .ForEach(num => Console.WriteLine(num));
        }
    }
}
