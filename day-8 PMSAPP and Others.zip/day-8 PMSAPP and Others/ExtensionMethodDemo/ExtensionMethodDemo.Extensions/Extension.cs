﻿using ExtensionMethodDemo.CalculationLibrary;

namespace ExtensionMethodDemo.Extensions
{
    public static class Extension
    {
        public static int Multiply(this ICalculation calculation, int x, int y)
        {
            return (x * y);
        }
    }
}
