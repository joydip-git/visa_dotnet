﻿namespace ExtensionMethodDemo.CalculationLibrary
{
    public interface ICalculation
    {
        int Add(int x, int y);
    }
}