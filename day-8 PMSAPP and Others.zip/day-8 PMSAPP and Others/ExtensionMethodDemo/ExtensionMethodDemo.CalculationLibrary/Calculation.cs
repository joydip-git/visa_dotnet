﻿namespace ExtensionMethodDemo.CalculationLibrary
{
    public class Calculation : ICalculation
    {
        public int Add(int x, int y)
        {
            return (x + y);
        }
    }
}
