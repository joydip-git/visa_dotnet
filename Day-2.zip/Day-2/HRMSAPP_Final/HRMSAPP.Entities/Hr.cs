﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSAPP.Entities
{
    public class Hr : Employee
    {
        private decimal gratuityPayment;

        /// <summary>
        /// default constructor
        /// </summary>
        public Hr()
        {

        }
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="name">name of an hr</param>
        /// <param name="id">id of an hr</param>
        /// <param name="basicPay">basic payment of an hr</param>
        /// <param name="daPay">da payment of an hr</param>
        /// <param name="hraPay">hra payment of an hr</param>
        /// <param name="gratuityPay">gratuity payment of an hr</param>
        public Hr(string name, int id, decimal basicPay, decimal daPay, decimal hraPay, decimal gratuityPay) : base(name, id, basicPay, daPay, hraPay)
        {
            this.gratuityPayment = gratuityPay;
        }

        /// <summary>
        /// gets or sets the gratuity payment
        /// </summary>
        public decimal GratuityPayment
        {
            get => gratuityPayment; set => gratuityPayment = value;
        }

        /// <summary>
        /// Method to calculate total salary of a developer
        /// </summary>
        /// <returns>
        /// returns total calculated salary
        /// </returns>
        public override decimal CalculateSalary()
        {
            return base.CalculateSalary() + this.gratuityPayment;
        }
    }
}
