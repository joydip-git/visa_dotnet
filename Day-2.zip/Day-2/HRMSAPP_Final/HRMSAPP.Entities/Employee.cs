﻿namespace HRMSAPP.Entities
{
    /// <summary>
    /// Employee class
    /// </summary>
    public class Employee
    {
        #region Data Members
        private readonly int id;
        private string name;
        private decimal basicPayment;
        private decimal daPayment;
        private decimal hraPayment;
        //field initialization
//#pragma warning disable IDE0044 // Add readonly modifier
        private static decimal joiningBonusPayment;// = 1000;
//#pragma warning restore IDE0044 // Add readonly modifier
        public const decimal YEARLYBONUS = 2000;
        //private readonly static decimal relocationPayment;//=10000;
        #endregion

        #region Constructors
        //don't declare the static ctor with any access specifier
        //can't be overloaded
        //you don't call this ctor explicitly
        //this gets called implicitly whenever you try to create an instance of the class and invoke default/parameterized ctor or you call any static property/method of this class
        //used to initialize only static fields
        //this ctor gets executed only once (during lifetime of the application)
        static Employee()
        {
            //System.Console.WriteLine("static ctor executed");
            joiningBonusPayment = 1000;
            //relocationPayment = 10000;
        }
        /// <summary>
        /// default constructor
        /// </summary>
        public Employee()
        {

        }
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="name">name of employee</param>
        /// <param name="id">id of employee</param>
        /// <param name="basicPay">basic payment of employee</param>
        /// <param name="daPay">da payment of employee</param>
        /// <param name="hraPay">hra payment of employee</param>
        public Employee(string name, int id, decimal basicPay, decimal daPay, decimal hraPay)
        {
            this.name = name;
            this.id = id;
            this.basicPayment = basicPay;
            this.daPayment = daPay;
            this.hraPayment = hraPay;
        }
        #endregion

        #region Properties
        /// <summary>
        /// gets or sets the hra payment
        /// </summary>
        public decimal HraPayment
        {
            get { return hraPayment; }
            set { hraPayment = value; }
        }
        /// <summary>
        /// gets or sets the da payment
        /// </summary>
        public decimal DaPayment
        {
            get { return daPayment; }
            set { daPayment = value; }
        }
        /// <summary>
        /// gets or sets the basic payment
        /// </summary>
        public decimal BasicPayment
        {
            get { return basicPayment; }
            set { basicPayment = value; }
        }
        /// <summary>
        /// gets or sets the name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        /// <summary>
        /// gets or sets the id
        /// </summary>
        public int Id
        {
            get { return id; }
            //set { id = value; }
        }
        /// <summary>
        /// gets the joining bonus payment
        /// </summary>
        //public decimal JoiningBonusPayment => joiningBonusPayment;
        public static decimal JoiningBonusPayment
        {
            get => joiningBonusPayment;
        }
        /// <summary>
        /// gets the relocation payment
        /// </summary>
        //public static decimal RelocationPayment => relocationPayment;
        #endregion

        #region Methods
        /// <summary>
        /// Method to calculate total salary of an employee
        /// </summary>
        /// <returns>
        /// returns total calculated salary
        /// </returns>
        public virtual decimal CalculateSalary()
        {
            //return this.basicPayment + this.daPayment + this.hraPayment + joiningBonusPayment + YEARLYBONUS + relocationPayment;
            return this.basicPayment + this.daPayment + this.hraPayment + joiningBonusPayment + YEARLYBONUS ;
        }
        #endregion
    }
}
