﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSAPP.Entities
{
    /// <summary>
    /// Developer class
    /// </summary>
    public class Developer : Employee
    {
        private decimal incentivePayment;

        /// <summary>
        /// default constructor
        /// </summary>
        public Developer()
        {

        }
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="name">name of developer</param>
        /// <param name="id">id of developer</param>
        /// <param name="basicPay">basic payment of developer</param>
        /// <param name="daPay">da payment of developer</param>
        /// <param name="hraPay">hra payment of developer</param>
        /// <param name="incentivePay">incentive payment of developer</param>
        public Developer(string name, int id, decimal basicPay, decimal daPay, decimal hraPay, decimal incentivePay) : base(name, id, basicPay, daPay, hraPay)
        {
            this.incentivePayment = incentivePay;
        }

        /// <summary>
        /// gets or sets the incentive payment
        /// </summary>
        public decimal IncentivePayment
        {
            get => incentivePayment; set => incentivePayment = value;
        }
        /// <summary>
        /// Method to calculate total salary of a developer
        /// </summary>
        /// <returns>
        /// returns total calculated salary
        /// </returns>
        public override decimal CalculateSalary()
        {
            return base.CalculateSalary() + this.incentivePayment;
        }
    }
}
