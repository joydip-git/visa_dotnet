﻿using HRMSAPP.Entities;
using System;

namespace HRMSAPP.UserInterface.Utilities
{
    public static class EmployeeUtility
    {
        public static int GetCount()
        {
            Console.Write("How many employee records? ");
            return int.Parse(Console.ReadLine());
        }
        public static void ShowMenu()
        {
            Console.WriteLine("\n1. Developer record");
            Console.WriteLine("2. Hr record");
        }
        public static int GetChoice()
        {
            Console.Write("\nEnter choice[1/2]: ");
            return int.Parse(Console.ReadLine());
        }
        public static Employee CreateEmployee(int choice)
        {
            Console.Write("\nName: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Basic Payment: ");
            decimal basicPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Da Payment: ");
            decimal daPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Hra Payment: ");
            decimal hraPayment = decimal.Parse(Console.ReadLine());

            Employee employee = null;
            switch (choice)
            {
                case 1:
                    Console.Write("Incentive Payment: ");
                    decimal incentivePayment = decimal.Parse(Console.ReadLine());
                    employee = new Developer(name,id,basicPayment,daPayment,hraPayment,incentivePayment);
                    break;
                case 2:
                    Console.Write("Gratuity Payment: ");
                    decimal gratuityPayment = decimal.Parse(Console.ReadLine());
                    employee = new Hr(name, id, basicPayment, daPayment, hraPayment, gratuityPayment);
                    break;
                default:
                    break;
            }
            //return new Employee(name, id, basicPayment, daPayment, hraPayment);
            return employee;
        }
        public static void SaveEmployee(int recordCount, Employee[] employees,int choice)
        {
            for (int i = 0; i < recordCount; i++)
            {
                Console.WriteLine($"\nRecord#{i + 1}");
                Employee employee = CreateEmployee(choice);
                employees[i] = employee;
            }
        }
        public static void PrintEmployeeSalary(Employee[] employees)
        {
            foreach (Employee employee in employees)
            {
                Console.WriteLine($"{employee.Name} has got salary of {employee.CalculateSalary()}");
            }
        }
    }
}
