﻿using HRMSAPP.Entities;
using HRMSAPP.UserInterface.Utilities;

namespace HRMSAPP.UserInterface
{
    class Program
    {
        static void Main()
        {
            int recordCount = EmployeeUtility.GetCount();
            Employee[] employees = new Employee[recordCount];
            EmployeeUtility.ShowMenu();
            int choice = EmployeeUtility.GetChoice();
            EmployeeUtility.SaveEmployee(recordCount, employees,choice);
            EmployeeUtility.PrintEmployeeSalary(employees);
        }
    }
}
