﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo.Logic
{
    public class Trainee
    {
        #region Data Members
        string name;
        int id;
        string subject;
        double marks;
        string projectName;
        #endregion

        #region Constructors
        public Trainee()
        {

        }
        public Trainee(string name, int id, string subject, double marks, string project)
        {
            this.name = name;
            this.id = id;
            this.subject = subject;
            this.marks = marks;
            this.projectName = project;
        }
        #endregion

        #region Properties
        public string Name
        {
            //public void SetName(string name)
            set
            {
                this.name = value;
            }
            //public string GetName()
            get
            {
                return name;
            }
        }

        public int Id { get => id; set => id = value; }
        public string Subject { get => subject; set => subject = value; }
        public double Marks { get => marks; set => marks = value; }
        public string ProjectName { get => projectName; set => projectName = value; }

        //public string Subject => subject; //(property with get accessor using lambda)
        #endregion

        #region Methods
        /*
        public string GetInformation()
        {
            return $"Name:{name}, Id:{id}, Subject:{subject} and Marks:{marks}";
        }
        */
        public virtual string GetInformation() =>        
             $"Name:{name}, Id:{id}, Subject:{subject} and Marks:{marks}";
        #endregion

    }
}
