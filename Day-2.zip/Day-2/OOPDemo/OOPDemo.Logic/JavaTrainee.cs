﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo.Logic
{
    public class JavaTrainee : Trainee
    {
        private string javaDomainSpeciality;
        public JavaTrainee() { }
        public JavaTrainee(string name, int id, string subject, double marks, string project, string specility)
            : base(name, id, subject, marks, project)
        {
            this.javaDomainSpeciality = specility;
        }

        public string JavaDomainSpeciality
        {
            get => javaDomainSpeciality;
            set => javaDomainSpeciality = value;
        }
        public override string GetInformation() =>
             $"{base.GetInformation()}, Speciality: {this.javaDomainSpeciality}";
    }
}
