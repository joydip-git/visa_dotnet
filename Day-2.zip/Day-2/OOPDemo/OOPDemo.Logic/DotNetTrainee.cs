﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo.Logic
{
    public class DotNetTrainee : Trainee
    {
        private string dotnetDomainSpecilaity;
        public DotNetTrainee() { }
        public DotNetTrainee(string name, int id, string subject, double marks, string project, string specility)
            : base(name, id, subject, marks, project)
        {
            this.dotnetDomainSpecilaity = specility;
        }

        public string DotnetDomainSpecilaity
        {
            get => dotnetDomainSpecilaity;
            set => dotnetDomainSpecilaity = value;
        }
        public string GetInformation() =>
             $"{base.GetInformation()}, Speciality: {this.dotnetDomainSpecilaity}";
    }
}
