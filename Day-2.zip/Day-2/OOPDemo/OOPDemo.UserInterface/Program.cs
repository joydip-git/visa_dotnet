﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OOPDemo.Logic;

namespace OOPDemo.UserInterface
{
    class Program
    {
        static void Add(int x, int y)
        {

        }
        static void Add(int a, int y, int z)
        {

        }
        static void Add(int x, int y, long z)
        {

        }
        static void Add(int x, long y, int z)
        {

        }
        //unsafe static void Main()
        static void Main()
        {
            //int x = 10;
            //int* p = &x;
            /*
            Trainee joyStudent = new Trainee("joy", 1, "DotNet", 56, null);
            joyStudent.Name = "joydip";
            string information = joyStudent.GetInformation();
            Console.WriteLine(information);
            Console.WriteLine(joyStudent.Name);

            Trainee anilStudent = new Trainee("anil", 2, "Java", 67, null);
            string anilInfo = anilStudent.GetInformation();
            */
            Trainee joyTrainee = new DotNetTrainee("joy", 1, "DotNet", 56, null,"CSharp");
            Trainee anilTrainee = new JavaTrainee("anil", 2, "Java", 67, null, "Spring");
            PrintInformation(joyTrainee);
            PrintInformation(anilTrainee);
        }
        //static void PrintInformation(DotNetTrainee dotNetTrainee)
        //{
        //    Console.WriteLine(dotNetTrainee.GetInformation());
        //}
        //static void PrintInformation(JavaTrainee javaTrainee)
        //{
        //    Console.WriteLine(javaTrainee.GetInformation());
        //}
        static void PrintInformation(Trainee trainee)
        {
            //if(trainee is DotNetTrainee)
            //{
            //    DotNetTrainee dotNetTrainee = trainee as DotNetTrainee;
            //    Console.WriteLine(dotNetTrainee.GetInformation());
            //}
            //if (trainee is JavaTrainee)
            //{
            //    JavaTrainee javaTrainee = trainee as JavaTrainee;
            //    Console.WriteLine(javaTrainee.GetInformation());
            //}
            Console.WriteLine(trainee.GetInformation());
        }
    }
}
