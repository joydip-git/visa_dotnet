﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MultilevelInheritance
{
    class A
    {
        public virtual void Test()
        {
            Console.WriteLine("A Test");
        }
        public void Foo()
        {
            this.Test();
        }
        public static void StaticTest()
        {

        }
    }
    class B : A
    {
        public override void Test()
        {
            base.Foo();
            Console.WriteLine("B Test");
        }
    }
    class C : B
    {
        public override void Test()
        {
            Console.WriteLine("C Test");
        }
    }
    class Program
    {
        static void Main()
        {
            //A objB = new B();
            //objB.Test();

            A objC1 = new C();
            objC1.Test();

            //B objC2 = new C();
            //objC2.Test();

            //A obj = new A();
            //obj.Foo();
            //A.StaticTest();
            Type t = typeof(A);
            Console.WriteLine(t.FullName);
            MethodInfo[] allMethods = t.GetMethods();
            foreach (MethodInfo mi in allMethods)
            {
                Console.WriteLine(mi.Name);
            }
            
        }
    }
}
