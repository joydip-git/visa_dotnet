﻿using AbstractDemo.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo.UserInterface
{
    abstract class A
    {
        string name;
        public A()
        {

        }
        public A(string name)
        {
            this.name = name;
        }
        public abstract string Sample { set; get; }
        public string Name { get => name; set => name = value; }

        public abstract void Test();
        public string Print()
        {
            return this.name;
        }
    }
    class B : A
    {
        string sample;
        public override string Sample
        {
            get => sample;
            set => sample = value;
        }
        public override void Test()
        {
            Console.WriteLine("test method");
        }
    }
    class Program
    {
        static void ShowMenu()
        {
            Console.WriteLine("1. get data from file");
            Console.WriteLine("2. get data from db");
        }
        static int GetChoice()
        {
            Console.WriteLine("\nenter choice: ");
            return int.Parse(Console.ReadLine());
        }
        static DataAccessChoice ConvertChoice(int choice)
        {
            DataAccessChoice dataAccessChoice; 
            switch (choice)
            {
                case 1:
                    dataAccessChoice = DataAccessChoice.AccessFromFile;
                    break;

                case 2:
                    dataAccessChoice = DataAccessChoice.AccessFromDb;
                    break;

                default:
                    dataAccessChoice = DataAccessChoice.AccessFromFile;
                    break;
            }
            return dataAccessChoice;
        }
        static DataAccess Create(DataAccessChoice choice)
        {
            DataAccess dataAccessObject = null;
            switch (choice)
            {
                case DataAccessChoice.AccessFromFile:
                    dataAccessObject = new FileDataAccess();
                    break;

                case DataAccessChoice.AccessFromDb:
                    dataAccessObject = new DbDataAccess();
                    break;

                default:
                    dataAccessObject = new FileDataAccess();
                    break;
            }
            return dataAccessObject;
        }
        static void Main()
        {
            ShowMenu();
            int choice = GetChoice();
            DataAccessChoice dataAccessChoice = ConvertChoice(choice);
            string path = ConfigurationManager.AppSettings["path"];           
            DataAccess fd = Create(dataAccessChoice);
            fd.Path = path;
            fd.GetData();
            string data = fd.Data;
            if (data != null && data != "")
            {
                Console.WriteLine(data);
            }
            else
                Console.WriteLine("something went wrong");

            Console.WriteLine("press any key to terminate....");
            Console.ReadLine();
        }
    }
}
