﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo.Entities
{
    public class DbDataAccess : DataAccess
    {
        string dbPath;
        public DbDataAccess()
        {

        }
        public DbDataAccess(string path)
        {
            dbPath = path;
        }
        public override string Path
        {
            get => dbPath;
            set => dbPath = value;
        }

        public override void GetData()
        {
            this.Data = "go data from database";
        }
    }
}
