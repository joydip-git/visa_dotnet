﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo.Entities
{
    public class FileDataAccess : DataAccess
    {
        string filePath;
        public FileDataAccess()
        {

        }
        public FileDataAccess(string path)
        {
            this.filePath = path;
        }
        public override string Path
        {
            get => filePath;
            set => filePath = value;
        }

        public override void GetData()
        {
            try
            {
                if (filePath != null && filePath != string.Empty)
                {
                    if (File.Exists(filePath))
                    {
                        StreamReader reader = new StreamReader(filePath);
                        this.Data = reader.ReadToEnd();
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
