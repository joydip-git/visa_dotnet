﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo.Entities
{
    public enum DataAccessChoice //:byte,sbyte,short,ushort,int,uint,long,ulong
    {
        AccessFromFile,//=0
        AccessFromDb //=1
    }
}
