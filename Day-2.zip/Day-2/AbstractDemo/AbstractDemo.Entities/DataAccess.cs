﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo.Entities
{
    public abstract class DataAccess
    {
        string data;
        public DataAccess()
        {

        }
        public string Data { get => data; protected set => data = value; }
        public abstract string Path { set; get; }
        public abstract void GetData();
    }
}
