﻿using CalculationLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace HostApp
{
    class Program
    {
        static void Main()
        {
            using (ServiceHost host = new ServiceHost(typeof(Calculation)))
            {
                host.Open();
                Console.WriteLine("host is running");
                Console.WriteLine("press any key to terminate...");
                Console.ReadLine();
                host.Close();
            }
        }
    }
}
