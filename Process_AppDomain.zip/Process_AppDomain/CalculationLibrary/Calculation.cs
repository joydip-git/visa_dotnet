﻿using System.ServiceModel;

namespace CalculationLibrary
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class Calculation : ICalculation
    {
        public Calculation()
        {
            System.Console.WriteLine("object created");
        }
        public int Add(int x, int y)
        {
            return (x + y);
        }
    }
}
