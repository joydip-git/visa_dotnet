﻿using System.ServiceModel;

namespace CalculationLibrary
{
    [ServiceContract]
    public interface ICalculation
    {
        [OperationContract]
        int Add(int x, int y);
    }
}