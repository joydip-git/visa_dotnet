﻿using System;
using TestClient.calcsvcref;

namespace TestClient
{
    class Program
    {
        static void Main()
        {
            using (CalculationClient proxy = new CalculationClient())
            {
                var res = proxy.Add(12, 13);
                //IMessage: "Add",new object[]{12,13}
                Console.WriteLine(res);
            }
        }
    }
}
