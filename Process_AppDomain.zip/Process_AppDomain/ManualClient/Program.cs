﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManualClient
{
    class Program
    {
        static void Main(string[] args)
        {
            using (CalculationClient proxy = new CalculationClient())
            {
                var res1 = proxy.Add(12, 13);
                var res = proxy.Add(12, 1);
                //IMessage: "Add",new object[]{12,13}
                Console.WriteLine(res1);
                Console.WriteLine(res);
            }
        }
    }
}
