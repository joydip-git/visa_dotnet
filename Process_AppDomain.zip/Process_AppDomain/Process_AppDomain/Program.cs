﻿//using CalculationLibrary;
using System;
using System.Diagnostics;
using System.Reflection;

namespace Process_AppDomain
{
    class Program
    {
        //static void Calculate()
        //{
        //    Calculation calculation = new Calculation();
        //    Console.WriteLine(calculation.Add(12, 13));
        //}
        static void PrintProcessInfo()
        {
            var currentProcess = Process.GetCurrentProcess();
            Console.WriteLine($"Process Name: {currentProcess.ProcessName} and Id: {currentProcess.Id}");
        }
        static AppDomain PrintAppDomainInfo()
        {
            Console.WriteLine("\n");
            AppDomain currentDomain = AppDomain.CurrentDomain;
            Console.WriteLine($"App Domain name: {currentDomain.FriendlyName}");
            return currentDomain;
        }
        static void Main()
        {
            //Calculate();
            PrintProcessInfo();
            var domain = PrintAppDomainInfo();
            PrintLoadedAssembly(domain);
            CreateDomain();
            Console.WriteLine("enter press to terminate the app");
            Console.ReadLine();
        }

        private static void CreateDomain()
        {
            AppDomain newDomain = AppDomain.CreateDomain("second");
            Console.WriteLine($"\nassemblies in {newDomain.FriendlyName} domain");
            //PrintLoadedAssembly(newDomain);
            LoadAssembly(newDomain);
        }

        private static void LoadAssembly(AppDomain newDomain)
        {
            Assembly loadedAsm =
                newDomain.Load("CalculationLibrary");
            PrintLoadedAssembly(newDomain);
            //object obj = Activator.CreateInstance(loadedAsm.GetType("CalculationLibrary.Calculation"));
            var obj = newDomain.CreateInstance(loadedAsm.FullName, "CalculationLibrary.Calculation");
                if(obj !=null)
                Console.WriteLine("object created");
            else
                Console.WriteLine("not created...");
        }

        private static void PrintLoadedAssembly(AppDomain domain)
        {
            Console.WriteLine("\n\n");
            Assembly[] all = domain.GetAssemblies();
            foreach (Assembly asm in all)
            {
                Console.WriteLine($"Name: {asm.FullName}");
            }
        }
    }
}
