﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaDemo
{
    class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
    class Program
    {
        static bool IsEven(int x)
        {
            return x % 2 == 0;
        }
        static void Main()
        {
            Predicate<int> isOdd = delegate (int a) { return a % 2 != 0; };
            Predicate<int> isEven = new Predicate<int>(Program.IsEven);

            Func<int, bool> isOddLogic = a => a % 2 != 0;
            Func<int, bool> isEvenLogic = x => x % 2 == 0;

            Func<int, int, int> addLogic = (a, b) => (a + b);

            List<Product> products = new List<Product>
            {
                new Product{ Id=2, Name="The alchemist", Price=799 },
                new Product{ Id=1, Name="Pillars of the earth", Price=899 },
                new Product{ Id=3, Name="Gratvity", Price=599 },
            };

            int choice = 3;
            Comparison<Product> compDel = null;
            switch (choice)
            {
                case 1:
                    compDel = (p1, p2) => p1.Id.CompareTo(p2.Id);
                    break;

                case 2:
                    compDel = (p1, p2) => p1.Name.CompareTo(p2.Name);
                    break;

                case 3:
                    compDel = (p1, p2) => p1.Price.CompareTo(p2.Price);
                    break;

                default:
                    compDel = (p1, p2) => p1.Id.CompareTo(p2.Id);
                    break;
            }
            //products.Sort(compDel);
            for (int i = 0; i < products.Count; i++)
            {
                for (int j = i + 1; j < products.Count; j++)
                {
                    //if (products[i].CompareTo(products[j]) > 0)
                    //if (comp.Compare(products[i],products[j]) > 0)
                    if (compDel(products[i], products[j]) > 0)
                    {
                        Product temp = products[i];
                        products[i] = products[j];
                        products[j] = temp;
                    }
                }
            }
            foreach (Product item in products)
            {
                Console.WriteLine($"{item.Name} {item.Id} {item.Price}");
            }
        }
    }
}
