﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegtesimplementation
{
    delegate int CalDel(int a, int b);
    class Calculation
    {
        public int Add(int a, int b)
        {
            return (a + b);
        }
        public static int Multiply(int a, int b)
        {
            return (a * b);
        }
    }
    delegate bool LogicInvoker(int num);
    delegate bool LogicInvoker<in T>(T num);
    class Logic
    {
        public bool IsEven(int num)
        {
            return num % 2 == 0;
        }
        public bool IsOdd(int num)
        {
            return num % 2 != 0;
        }
    }
    class Program
    {
        static List<T> Filter<T>(List<T> input, LogicInvoker<T> logic)
        {
            List<T> result = new List<T>();
            //Logic logic = new Logic();
            foreach (T item in input)
            {
                if (logic.Invoke(item))
                    result.Add(item);
            }
            return result;
        }
        static void Main()
        {
            CalDel cdAdd = new CalDel(new Calculation().Add);
            CalDel cdMultiply = Calculation.Multiply;
            int resAdd = cdAdd(12, 13);
            int resMultiply = cdMultiply.Invoke(12, 4);
            Console.WriteLine(resAdd);
            Console.WriteLine(resMultiply);

            //data source
            List<int> numbers = new List<int> { 0, 8, 1, 3, 2, 5, 7, 6, 4, 9 };
            //logic
            //LogicInvoker<int> evenLogic = new LogicInvoker<int>(new Logic().IsEven);
            //LogicInvoker<int> oddLogic = new LogicInvoker<int>(new Logic().IsOdd);


            //get the list filtered
            //List<int> output = Filter<int>(numbers, evenLogic);

            //LogicInvoker<int> greaterThanLogic = public bool IsGreater(int num)
            //{
            //    return num > 5;
            //};

            //anonymus method being referred by a delegate
            //LogicInvoker<int> greaterThanLogic = delegate (int num)
            //{
            //    return num > 5;
            //};

            //anonymous method using Lambda expression
            //LogicInvoker<int> greaterThanLogic = (a) => a > 5;

            //List<int> output = Filter(numbers, greaterThanLogic);
            //List<int> output = Filter(numbers, a => a > 5);
            List<int> output = Filter(numbers, a => { return a % 2 == 0; });
            foreach (int item in output)
            {
                Console.WriteLine(item);
            }
        }
    }
}
