﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ProductLibrary;

namespace ProductDataLibrary
{
    public static class ProductRespository
    {
        private static List<Product> products;
        static ProductRespository()
        {
            products = new List<Product>
            {
                new Product{ Id=2, Name="The alchemist", Price=799 },
                new Product{ Id=1, Name="Pillars of the earth", Price=899 },
                new Product{ Id=3, Name="Gravity", Price=599 },
            };
        }
        public static List<Product> GetProducts()
        {
            return products;
        }
    }
}
