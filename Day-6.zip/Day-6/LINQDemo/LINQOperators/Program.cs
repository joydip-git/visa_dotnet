﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ProductLibrary;
using ProductDataLibrary;

namespace LINQOperators
{
    class Program
    {

        static void Main()
        {
            List<Product> products = ProductRespository.GetProducts();
            //select count(p.name) as productcount, avg(p.price) as avgprice from products p;

            var statistics = new { products.Count, Average = products.Average(p => p.Price) };
            //statistics.Count = 4;

            Console.WriteLine($"{statistics.Count} {statistics.Average}");
            products
                .Where(p => p.Price > 600)
                .Select(p => new { Name = p.Name })
                .ToList()
                .ForEach(a => Console.WriteLine($"{a.Name}"));

            var person = new { FirstName = "joydip", LastName = "mondal" };
            //person.FirstName = "joy";
            Console.WriteLine(person.GetType().Name);
            //var person1 = person;
            var person1 = new { person.FirstName };
            Console.WriteLine(person1.GetType().Name);

            //x=> strongly typed local variable
            int x = 10;

            //y = > implicitly typed LOCAL variable
            //interpreting type of 'y' from the value assigned tp y is known as => type inference
            var y = 20;

            IEnumerable<IGrouping<char, Product>> query = from p in products
                                                          orderby p.Name
                                                          group p by p.Name[0];
            foreach (IGrouping<char, Product> group in query)
            {
                Console.WriteLine(group.Key);
                Console.WriteLine("-----------------------");
                foreach (Product item in group)
                {
                    Console.WriteLine($"{item.Name}");
                }
                Console.WriteLine("\n");
            }

            //var (JS) => loosely typed vs var (C#)=>implicitly typed
            //var x = 10; x = false;  y =10;
        }
    }
}
