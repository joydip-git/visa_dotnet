﻿using System;
using System.Collections.Generic;
using System.Linq;

using ProductLibrary;
using ProductDataLibrary;

namespace LINQDemo
{
    //delegate bool LogicInvoker<in T>(T obj);
    class Program
    {
        //static List<T> Filter<T>(List<T> input, LogicInvoker<T> logic)
        //static List<T> Filter<T>(List<T> input, Predicate<T> logic)
        static IEnumerable<T> Filter<T>(List<T> input, Func<T, bool> logic)
        {
            List<T> res = new List<T>();
            foreach (T item in input)
            {
                if (logic(item))
                {
                    res.Add(item);
                }
            }
            return res;
        }
        static void Main()
        {
            //data source
            List<Product> products = ProductRespository.GetProducts();

            //LogicInvoker<Product> logic = delegate (Product p)
            //{
            //    return p.Name.Contains<char>('e');                
            //};
            //Predicate<Product> logic = (p) => p.Name.Contains<char>('e');

            //Func<Product,bool> logic = (p) => p.Name.Contains<char>('e');

            //List<Product> result = Filter<Product>(products, logic) as List<Product>;

            //foreach (Product item in result)
            //{
            //    Console.WriteLine(item.Name);
            //}
            //LINQ: Language Integrated Query
            //1. Query Operator syntax

            //select p.name from products p where p.name like %'e'% order by p.name
            IEnumerable<string> query =
                                        from p in products
                                        where p.Name.Contains<char>('e')
                                        orderby p.Name
                                        select p.Name;
            query.ToList<string>().ForEach(name => Console.WriteLine(name));

            //2. Method query syntax
            //Func<Product, bool> logic = (p) => p.Name.Contains<char>('e');
            //IEnumerable<Product> res = products.Where(logic);
            //List<Product> resFinal = res.ToList<Product>();

            //Logic1
            //Func<Product, bool> logic = (p) => p.Name.Contains<char>('e');
            //filtration
            //IEnumerable<Product> res = products.Where(logic);

            //Logic2:
            //Func<Product, string> logicSelection = p => p.Name;
            //selection
            //IEnumerable<string> names = res.Select(logicSelection);

            //Action<string> printDel = (name) => Console.WriteLine(name);


            var res = products
                  .Where(p => p.Name.Contains<char>('e'))
                  .OrderBy(p => p.Name)
                  .Select(p => p.Name);

            
            res.ToList<string>()
            .ForEach(name => Console.WriteLine(name));

            //products.Add(new Product { Id = 4, Name = "abcde", Price = 699 });

            res.ToList<string>()
            .ForEach(name => Console.WriteLine(name));

            //foreach (string item in names)
            //{
            //    Console.WriteLine(item);
            //}
        }
    }
}
