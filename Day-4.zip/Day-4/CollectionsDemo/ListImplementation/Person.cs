﻿using System;

namespace ListImplementation
{
    class Person : IComparable, IComparable<Person>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Person()
        {

        }
        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        //generic interface method
        public int CompareTo(Person other)
        {
            if (other != null)
            {
                if (this == other)
                    return 0;

                if (this.FirstName.CompareTo(other.FirstName) == 0)
                    return this.LastName.CompareTo(other.LastName);
                else
                    return this.FirstName.CompareTo(other.FirstName);
            }
            else
                throw new NullReferenceException("null reference was passed to CompareTo method");
        }
        //non-generic interface method
        public int CompareTo(object obj)
        {
            if (obj != null)
            {
                if (obj is Person)
                {
                    Person other = obj as Person;

                    if (this == other)
                        return 0;

                    if (this.FirstName.CompareTo(other.FirstName) == 0)
                        return this.LastName.CompareTo(other.LastName);
                    else
                        return this.FirstName.CompareTo(other.FirstName);
                }
                else
                    throw new ArgumentException("reference of Person type was not passed to CompareTo method");
            }
            else
                throw new NullReferenceException("null reference was passed to CompareTo method");
        }
    }
}
