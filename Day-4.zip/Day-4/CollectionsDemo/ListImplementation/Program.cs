﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ListImplementation
{
    class MyList<T>
    {
        T[] items;

        public void Sort()
        {
            Type t = typeof(T);
            Type[] interfaces = t.GetInterfaces();
            foreach (Type interfaceType in interfaces)
            {
                if (interfaceType is IComparable || interfaceType is IComparable<T>)
                {
                    //IComparable comparable = T;
                    for (int i = 0; i < items.Length; i++)
                    {
                        for (int j = i + 1; j < items.Length; j++)
                        {
                            //if (items[i] > items[j])
                            //if (items[i].CompareTo(items[j]) > 0)
                            //{
                            //    int temp = items[i];
                            //    items[i] = items[j];
                            //    items[j] = temp;
                            //}
                        }
                    }
                }
                throw new InvalidOperationException();
            }
        }
        public void Sort(IComparer<T> compr)
        {
            for (int i = 0; i < items.Length; i++)
            {
                for (int j = i + 1; j < items.Length; j++)
                {

                    if (compr.Compare(items[i], items[j]) > 0)
                    {
                        T temp = items[i];
                        items[i] = items[j];
                        items[j] = temp;
                    }
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            //belongs to [System] namespace
            //IComparable <--non-generic
            //IComparable<int> <--generic
            List<int> numbers = new List<int>
            {
                12, 14, 13
            };
            numbers.Sort();
            //for (int i = 0; i < numbers.Count; i++)
            //{
            //    for (int j = i + 1; j < numbers.Count; j++)
            //    {
            //        //if (numbers[i] > numbers[j])
            //        if (numbers[i].CompareTo(numbers[j]) > 0)
            //        {
            //            int temp = numbers[i];
            //            numbers[i] = numbers[j];
            //            numbers[j] = temp;
            //        }
            //    }
            //}
            foreach (int item in numbers)
            {
                Console.WriteLine(item);
            }

            List<Person> people = new List<Person>
            {
                new Person { FirstName = "sunil", LastName = "gupta" },
                new Person { FirstName = "anil", LastName = "mishra" },
                new Person { FirstName = "banu praksah", LastName = "reddy" }
            };
            //expects IComparable/IComparable<T> is implemented in the entity
            //thus implementation of CompareTo is guranted
            //people.Sort();

            //inside logic of Sort()
            //for (int i = 0; i < people.Count; i++)
            //{
            //    for (int j = i + 1; j < people.Count; j++)
            //    {
            //        if (people[i].CompareTo(people[j]) > 0)
            //        {
            //            Person temp = people[i];
            //            people[i] = people[j];
            //            people[j] = temp;
            //        }
            //    }
            //}

            //expects the reference object that is being passed to the Sort method implements IComparer/IComparer<T> and thus Compare(T x, T y) method is guranteed
            PersonComparison pc = new PersonComparison(1);
            people.Sort(pc);

            //inside logic of Sort(IComparer<T> comp)
            /*
             * public void Sort(IComparer<T> compr)
               {
                for (int i = 0; i < items.Length; i++)
                {
                    for (int j = i + 1; j < items.Length; j++)
                    {
                        if (compr.Compare(items[i], items[j]) > 0)
                        {
                            T temp = items[i];
                            items[i] = items[j];
                            items[j] = temp;
                        }
                    }
                }
              }
             * */
            foreach (Person item in people)
            {
                Console.WriteLine($"{item.FirstName} {item.LastName}");
            }
        }
    }
}
