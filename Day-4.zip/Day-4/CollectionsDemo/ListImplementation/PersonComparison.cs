﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListImplementation
{
    class PersonComparison : IComparer<Person>
    {
        int choice;
        public PersonComparison()
        {

        }
        public PersonComparison(int choice)
        {
            this.choice = choice;
        }
        public int Compare(Person x, Person y)
        {
            int compValue = 0;
            switch (choice)
            {
                case 1:
                    compValue = x.FirstName.CompareTo(y.FirstName);
                    break;

                case 2:
                    compValue = x.LastName.CompareTo(y.LastName);
                    break;

                default:
                    compValue = x.FirstName.CompareTo(y.FirstName);
                    break;
            }
            return compValue;
        }
    }
}
