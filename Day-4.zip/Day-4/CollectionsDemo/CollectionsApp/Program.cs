﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CollectionsApp
{
    class A
    {

        //int x;
        //public int X
        //{
        //    set
        //    {
        //        if (value < 0)
        //            throw new Exception();
        //        else
        //            x = value;
        //    }
        //    get => x;
        //}


        //2007-3.0: automatic/auto-implemented property
        //private int _X_<back-up-field>;
        //public int X { set=> get=> }
        public int X { set; get; }
        public A()
        {

        }
        public A(int x)
        {
            X = x;
        }
    }
    class B : A { }
    class Program
    {
        static void Main()
        {

            /*
            //vt <--> vt
            
            int x = 10;
            //implicit conversion
            long l = x;
            
            //explicit conversion: casting
            long l1 = 1234567890123;
            //int y = (int)l1;
            int y = checked((int)l1);
            Console.WriteLine(y);
            //or explicit conversion: using Convert class method
            int z = Convert.ToInt32(l1);
            

            //rt <--> rt
            B objB = new B();
            //implicit conversion (upcasting)
            //object objA = objB;
            A objBRef = objB;

            //explicit conversion: casting
            //B obj1 = (B)objBRef;
            //explicit conversion: as operator
            B obj1 = objBRef as B;

            //B objB1 = new A(); <--not possible
            

            // vt <--> rt
            int a = 12;
            //implicit conversion (boxing)
            object obj = a;
            //explicit conversion (unboxing)
            long lvalue = (int)obj;
            Console.WriteLine(lvalue);
            */
            /*
            ArrayList al = new ArrayList();
            al.Add(12);
            al.Add(12.34);
            al.Add('a');
            al.Add("visa");
            //max index no <= number of elements already present
            al.Insert(0, "bangalore");
            foreach (object item in al)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("\nafter removal\n");
            al.Remove('a');
            al.RemoveAt(2);
            for (int i = 0; i < al.Count; i++)
            {
                Console.WriteLine(al[i]);
            }
            //al.Sort();
            //al.RemoveRange(0, 3);
            */

            List<int> numbers = new List<int>();

            // List<A> objects = new List<A>();
            //A ob1 = new A();
            //ob1.X = 10;
            //A ob2 = new A();
            //ob1.X = 20;
            //objects.Add(ob1);
            //objects.Add(ob2);

            //2007: 3.0: object initializer
            //A ob1 = new A { X = 10 };
            //A ob2 = new A { X = 20 };
            //2007-3.0: collection initializer
            //List<A> objects = new List<A>
            //{
            //    ob1, ob2
            //};
            List<A> objects = new List<A>
            {
                new A{ X = 10},
                new A{ X = 20}
            };
            foreach (A item in objects)
            {
                Console.WriteLine(item.X);
            }
            Console.WriteLine("\nset values\n");
            //HashSet<int> numberSet = new HashSet<int>
            //{
            //    12,13,12
            //};
            HashSet<int> numberSet = new HashSet<int>();
            numberSet.Add(12);
            numberSet.Add(13);
            numberSet.Add(12);
            foreach (int item in numberSet)
            {
                Console.WriteLine(item);
            }
        }
    }
}
