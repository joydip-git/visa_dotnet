alter table products
--add categoryid int
add productcode varchar(7) not null,
available_date varchar(50) not null,
star_rating decimal(2,1) not null default(0),
image_path varchar(max) not null