create procedure UpdateProduct
@name varchar(50),
@price decimal(18,2),
@desc varchar(max),
@code varchar(7),
@availability varchar(50),
@rating decimal(2,1),
@image varchar(max),
@catid int,
@pid int
as
begin
update products set productname = @name, price = @price, productdescription=@desc, productcode=@code,  available_date= @availability, star_rating=@rating,image_path = @image, categoryid=@catid where productid=@pid
end