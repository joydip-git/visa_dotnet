create procedure GetProductByProductId
@id int
as
begin
select * from products where productid=@id
end