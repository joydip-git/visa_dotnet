create table categories(
categoryid int not null identity(1,1) primary key,
categoryname varchar(50) not null
)