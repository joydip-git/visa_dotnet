create procedure GetProducts
as
begin
select * from products
end