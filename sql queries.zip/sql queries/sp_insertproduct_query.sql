create procedure AddProduct
@name varchar(50),
@price decimal(18,2),
@desc varchar(max),
@code varchar(7),
@availability varchar(50),
@rating decimal(2,1),
@image varchar(max),
@catid int
as
begin
insert into products(productname,productcode,price,productdescription,available_date,star_rating,image_path,categoryid) values(@name,@code,@price,@desc,@availability,@rating,@image,@catid)
end