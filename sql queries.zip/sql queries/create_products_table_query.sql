--create database visadb
--use visadb
create table products(
productid int not null primary key identity(100,1),
productname varchar(50) not null,
price decimal(18,2) default(0) not null,
productdescription varchar(max)
)