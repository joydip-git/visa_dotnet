USE [visadb]
GO

/****** Object:  Table [dbo].[products_audit]    Script Date: 8/16/2019 12:08:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[products_audit](
	[productid] [int] NOT NULL,
	[productname] [varchar](50) NOT NULL,
	[price] [decimal](18, 2) NOT NULL,
	[productdescription] [varchar](max) NULL,
	[modification_status] [varchar](10) NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[productcode] [varchar](7) NOT NULL,
	[available_date] [varchar](50) NOT NULL,
	[star_rating] [decimal](2, 1) NULL,
	[image_path] [varchar](max) NOT NULL,
	[categoryid] [int] NULL,
	[audit_id] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_products_audit] PRIMARY KEY CLUSTERED 
(
	[audit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[products_audit] ADD  CONSTRAINT [DF__products___price__2A4B4B5E]  DEFAULT ((0)) FOR [price]
GO

ALTER TABLE [dbo].[products_audit] ADD  CONSTRAINT [DF__products___star___30F848ED]  DEFAULT ((0)) FOR [star_rating]
GO


