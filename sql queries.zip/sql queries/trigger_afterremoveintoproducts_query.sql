create trigger AfterRemoveInProducts on products
for delete
as
 
declare @pid int;
declare @pname varchar(50);
declare @pcode varchar(7);
declare @pdesc varchar(max);
declare @price decimal(18,2);
declare @rating decimal(2,1);
declare @image varchar(max);
declare @available varchar(50);
declare @catid int;
declare @modifieddate datetime;
declare @modifiedstatus varchar(10);

select @pid = i.productid from deleted i;
select @pname = i.productname from deleted i;
select @pcode = i.productcode from deleted i;
select @pdesc = i.productdescription from deleted i;
select @price = i.price from deleted i;
select @rating = i.star_rating from deleted i;
select @available = i.available_date from deleted i;
select @image = i.image_path from deleted i;
select @catid = i.categoryid from deleted i;

set @modifieddate = GETDATE();
set @modifiedstatus='removed';

insert into products_audit(productid, productname, price, productdescription, modification_status, modified_on,productcode,available_date, star_rating, image_path, categoryid) values(@pid, @pname, @price, @pdesc, @modifiedstatus, @modifieddate, @pcode, @available, @rating, @image, @catid)
go