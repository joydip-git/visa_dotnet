insert into categories(categoryname) values('gardentools')
insert into categories(categoryname) values('books')
delete from categories where categoryid=2
select * from categories
