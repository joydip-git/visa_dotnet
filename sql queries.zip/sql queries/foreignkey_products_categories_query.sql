alter table products
add constraint fk_categories_categoryid_products_categoryid foreign key (categoryid) references categories(categoryid)