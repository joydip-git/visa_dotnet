create trigger AfterInsertInProducts on products
for insert
as
 
declare @pid int;
declare @pname varchar(50);
declare @pcode varchar(7);
declare @pdesc varchar(max);
declare @price decimal(18,2);
declare @rating decimal(2,1);
declare @image varchar(max);
declare @available varchar(50);
declare @catid int;
declare @modifieddate datetime;
declare @modifiedstatus varchar(10);

select @pid = i.productid from inserted i;
select @pname = i.productname from inserted i;
select @pcode = i.productcode from inserted i;
select @pdesc = i.productdescription from inserted i;
select @price = i.price from inserted i;
select @rating = i.star_rating from inserted i;
select @available = i.available_date from inserted i;
select @image = i.image_path from inserted i;
select @catid = i.categoryid from inserted i;

set @modifieddate = GETDATE();
set @modifiedstatus='added';

insert into products_audit(productid, productname, price, productdescription, modification_status, modified_on,productcode,available_date, star_rating, image_path, categoryid) values(@pid, @pname, @price, @pdesc, @modifiedstatus, @modifieddate, @pcode, @available, @rating, @image, @catid)
go