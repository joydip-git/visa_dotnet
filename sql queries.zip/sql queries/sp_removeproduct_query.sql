create procedure RemoveProduct
@pid int
as
begin
delete from products where productid=@pid
end