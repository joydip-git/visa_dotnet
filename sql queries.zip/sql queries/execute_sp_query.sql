--execute AddProduct 'Leaf Rake', 1200.00,'Leaf rake with 48-inch wooden handle','GDN-0011', 'March 19 2016',3.2,'http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png',null

--execute AddProduct 'Garden Cart', 1100.00,'15 gallon capacity rolling garden cart','GDN-0023', 'March 18 2016',4.5,'http://openclipart.org/image/300px/svg_to_png/58471/garden_cart.png',null

--execute AddProduct 'Hammer', 900.00,'curved claw steel hammer','TBX-0048', 'May 21 2016',4.0,'http://openclipart.org/image/300px/svg_to_png/73/rejon_Hammer.png',null

exec GetProducts
exec GetProductByProductId 101

exec UpdateProduct 'Hammer', 900.00,'curved claw steel hammer','TBX-0048', 'May 21 2016',3.0,'http://openclipart.org/image/300px/svg_to_png/73/rejon_Hammer.png',1,102

execute UpdateProduct 'Garden Cart', 1100.00,'15 gallon capacity rolling garden cart','GDN-0023', 'March 18 2016',4.5,'http://openclipart.org/image/300px/svg_to_png/58471/garden_cart.png',1,101

execute UpdateProduct 'Leaf Rake', 1200.00,'Leaf rake with 48-inch wooden handle','GDN-0011', 'March 19 2016',3.2,'http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png',1,100

execute AddProduct 'Saw',1150.00,'15-inch steel blade hand saw','TBX-0022','June 20 2019',4.2,'http://openclipart.org/image/300px/svg_to_png/27070/egore911_saw.png',1

execute UpdateProduct 'Saw',1150.00,'15-inch steel blade hand saw','TBX-0022','June 20 2019',3.5,'http://openclipart.org/image/300px/svg_to_png/27070/egore911_saw.png',1,103

execute UpdateProduct 'Saw',1150.00,'15-inch steel blade hand saw','TBX-0022','June 20 2019',3.5,'http://openclipart.org/image/300px/svg_to_png/27070/egore911_saw.png',1,103

select * from products
select * from products_audit

update products set categoryid=3 where productid=103