﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedKeyword
{
    class Employee { }
    class Developer : Employee { }
    sealed class JuniorDeveloper : Developer { }
    abstract class Printer { public abstract void Print(); }

    class LaserJetPrinter : Printer
    {
        public sealed override void Print()
        {
            //A4
        }
    }
    class DeskJetPrinter : Printer
    {
        public override void Print()
        {
            throw new NotImplementedException();
        }
    }
    class HomeLaserJetPrinter : LaserJetPrinter
    {
        //public override void Print()
        //{
        //    throw new NotImplementedException();
        //}
    }
    class OfficeLaserJetPrinter : LaserJetPrinter
    {
        //public override void Print()
        //{
        //    throw new NotImplementedException();
        //}
    }
    class Program
    {
        static void Main()
        {
        }
    }
}
