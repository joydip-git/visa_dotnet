﻿using ContractLib;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLib
{    
    [Export(typeof(IBuilding))]
    public class Building:IBuilding
    {
        public string COMPANY = "Visa";
        private int id;
        private string name;
        //private List<IRoom> rooms;
        public Building()
        {

        }
        public Building(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string GetBuildingInfo()
        {
            return COMPANY;
        }
    }
}
