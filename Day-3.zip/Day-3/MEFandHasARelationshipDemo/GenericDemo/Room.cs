﻿using ContractLib;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDemo
{
    class Room
    {
        private int id;
        private string name;
        private IBuilding building;
        public Room()
        {

        }
        public Room(int id, string name, IBuilding building = null)
        {
            this.id = id;
            this.name = name;
            this.building = building;
        }
        [Import(typeof(IBuilding))]
        public IBuilding Building
        {
            get { return building; }
            set { building = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
    }
}
