﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace GenericDemo
{
    class Trainer
    {
        public int Id;
        public string Name;
        //public Trainee[] Trainees;
    }
    class Trainee
    {
        public int Id;
        public string Name;
        //public Trainer[] Trainees;
    }
    class TrainingInformation //asociation class
    {
        public DateTime StartDate;
        public DateTime EndDate;
        public string subject;
        public Trainer Trainer;
        public List<Trainee> Trainees;
    }
    class Program
    {
        static void Main()
        {
            //AssemblyCatalog composableParts = new AssemblyCatalog(typeof(Building).Assembly);
            DirectoryCatalog directory = new DirectoryCatalog(@"../../../TestLib/bin/debug");
            ICollection<DirectoryCatalog> directories = new List<DirectoryCatalog> { directory };
            AggregateCatalog composableParts = new AggregateCatalog(directories);
            CompositionContainer container = new CompositionContainer(composableParts);

            Room room = new Room(1, "Inclusion");
            container.ComposeParts(room);

            Console.WriteLine(room.Building.GetBuildingInfo());
        }
    }
}
