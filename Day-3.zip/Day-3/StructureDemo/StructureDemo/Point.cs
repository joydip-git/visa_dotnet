﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    struct Point
    {
        //public int x_ordinate;
        //public int y_ordinate;
        int x_ordinate;
        int y_ordinate;

        public Point(int x, int y)
        {
            x_ordinate = x;
            y_ordinate = y;
        }
        public int XOrdinate
        {
            set => x_ordinate = value;
            get => x_ordinate;
        }
        public int YOrdinate
        {
            set => y_ordinate = value;
            get => y_ordinate;
        }
        public string GetLocation()
        {
            return $"x ordinate: {x_ordinate} and y ordinate: {y_ordinate}";
        }
    }
}
