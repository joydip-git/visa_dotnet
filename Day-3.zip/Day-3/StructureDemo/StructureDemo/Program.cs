﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    class Program
    {
        static Point Create()
        {
            Point windowLocation = new Point();
            windowLocation.XOrdinate = 30;
            windowLocation.YOrdinate = 40;
            //Console.WriteLine(windowLocation.GetLocation());
            return windowLocation;
        }
        static void Main()
        {
            //Point windowLocation;
            //windowLocation.x_ordinate = 30;
            //windowLocation.y_ordinate = 40;


            //Point windowLocation = new Point(30,40);
            Point location = Create();
            Console.WriteLine(location.GetLocation());
        }
    }
}
