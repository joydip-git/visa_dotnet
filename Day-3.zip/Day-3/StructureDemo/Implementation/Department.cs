﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    struct Department
    {
        Employee employee;

        public Department(Employee employee)
        {
            this.employee = employee;
        }
        public Employee Employee
        {
            set => employee = value;
            get => employee;
        }
    }
}
