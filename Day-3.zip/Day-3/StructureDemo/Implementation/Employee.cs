﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    public class Employee
    {
        Address address;

        public Employee() { }
        public Employee(Address address)
        {
            this.address = address;
        }

        public Address Address { get => address; set => address = value; }
    }
}
