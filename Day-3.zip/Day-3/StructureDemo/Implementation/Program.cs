﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    class Program
    {
        static void Main()
        {
            Employee employee = new Employee(new Address(5, "HSR"));

            Department department = new Department(employee);
        }
    }
}
