﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    public struct Address
    {
        private int streetNo;
        private string locality;

        //public Address()
        //{

        //}
        public Address(int streetNo, string locality)
        {
            this.streetNo = streetNo;
            this.locality = locality;
        }

        public string Locality
        {
            get { return locality; }
            set { locality = value; }
        }
        public int StreetNo
        {
            get { return streetNo; }
            set { streetNo = value; }
        }

    }
}
