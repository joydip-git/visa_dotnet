﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDemo
{
    interface ICalculation<T1>
    {
        void Add(T1 a, T1 b);
    }
    class Calc : ICalculation<int>
    {
        public void Add(int a, int b)
        {
            throw new NotImplementedException();
        }
    }
    class Calc1<T1,T2> : ICalculation<T1>
    {
        public void Add(T1 a, T1 b)
        {
            throw new NotImplementedException();
        }
    }
    class Calculation<T1> : ICalculation<T1>
    {
        //T1 data;
        public void Add(T1 a, T1 b)
        {

        }
        public TResult Add<T, TResult>(T a, T b)
        {
            dynamic d1 = a;
            dynamic d2 = b;
            return d1 + d2;
        }
        public TResult Add<TResult>(T1 a, T1 b) //where T : class, new()
        {
            dynamic d1 = a;
            dynamic d2 = b;
            return d1 + d2;
        }
    }
    class Program
    {
        static void Main()
        {
            Calc1<int> cal1 = new Calc1<int>();
            //cal1.Add()
            int res = new Calculation<int>().Add<int>(12, 13);
            Console.WriteLine(res);
        }
    }
}
