﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InheritanceApp.Entities;

namespace InheritanceApp.IOC
{
    public interface IContainer
    {
        IDataAccess Create(DataAccessChoice choice, FileType fileType = FileType.Text);
    }
    public class ContainerFactory
    {
        private static IContainer container;

        public static IContainer CreateContainer()
        {
            if (container == null)
                container = new Container();

            return container;
        }
    }
    class Container : IContainer
    {
        //private static IContainer container;

        //private Container()
        //{

        //}
        public Container()
        {

        }
        //public static IContainer CreateContainer()
        //{
        //    if (container == null)
        //        container = new Container();
        //    return container;
        //}

        public IDataAccess Create(DataAccessChoice choice, FileType fileType = FileType.Text)
        {
            IDataAccess dataAccess = null;
            switch (choice)
            {
                case DataAccessChoice.Db:
                    //dataAccess = null;
                    break;

                case DataAccessChoice.File:
                    dataAccess = new FileDataAccess(@"", fileType);
                    break;
                default:
                    break;
            }

            return dataAccess;
        }
    }
}
