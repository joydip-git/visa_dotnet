﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using InheritanceApp.Entities;
using InheritanceApp.IOC;

using Unity.Injection;
using Unity;

namespace InheritanceApp.UserInterface
{
    class Program
    {
        static void Main()
        {
            //FileDataAccess fd = new FileDataAccess();
            //DataAccess fd = new FileDataAccess();
            //IDataAccess fd = new FileDataAccess();
            //fd.Path = "";

            IContainer container = ContainerFactory.CreateContainer();
            IDataAccess fd = container.Create(DataAccessChoice.File, FileType.XML);
            fd.GetData();
            string data = fd.Data;


            // IUnityContainer container = new UnityContainer();
            //container.RegisterFactory(typeof(FileDataAccess),null,Unity.Lifetime.IFactoryLifetimeManager
        }
    }
}
