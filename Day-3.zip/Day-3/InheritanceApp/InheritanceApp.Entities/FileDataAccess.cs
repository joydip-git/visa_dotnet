﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceApp.Entities
{
    public class FileDataAccess : DataAccess
    {
        string fileData;
        FileType fileType;
        public FileDataAccess()
        {

        }
        public FileDataAccess(string path,FileType fileType )
        {
            this.Path = path;
            this.fileType = fileType;
        }
        public override string Data
        {
            get => fileData;
            set => fileData = value;
        }
        public override void GetData()
        {
            
        }
    }
}
