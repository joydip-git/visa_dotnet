﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceApp.Entities
{
    public abstract class DataAccess : IDataAccess
    {
        string data;
        string path;
        public virtual string Data
        {
            get => data;
            set => data = value;
        }
        public string Path { get => path; set => path = value; }

        /*
         * even if you don't implement the abstract method of interface, at least you to declare the same with public access specifier and abstract keyword
         */
        public abstract void GetData();
    }
}
