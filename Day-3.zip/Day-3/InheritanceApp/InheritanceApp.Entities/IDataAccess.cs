﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceApp.Entities
{
    public enum DataAccessChoice
    {
        Db,
        File
    }
    public enum FileType
    {
        XML,
        Text,
        Excel
    }
    /*
     * interface members are by default public
     * interface members are by default abstract
     * no data memebers in interface
     * only properties and methods
     * interface should be implemented and that time here is no need of override keyword
     */
    public interface IDataAccess
    {
        string Data { get; set; }
        void GetData();
    }
    public interface IFileDataAccess : IDataAccess
    {
        FileType FileType { set; get; }
    }
}
