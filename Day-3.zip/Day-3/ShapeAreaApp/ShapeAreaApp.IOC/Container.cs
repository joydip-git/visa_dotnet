﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShapeAreaApp.Entities;

namespace ShapeAreaApp.IOC
{
    public class Container : IContainer
    {        
        public IShape CreateShape(ShapeType shapeType, params double[] arguments)
        {
            IShape shape = null;
            switch (shapeType)
            {
                case ShapeType.Circle:
                    shape = new Circle(arguments[0]);
                    break;
                case ShapeType.Triangle:
                    shape = new Triangle(arguments[0], arguments[1]);
                    break;
                case ShapeType.Rectangle:
                    break;
                default:
                    break;
            }
            return shape;
        }
    }
}
