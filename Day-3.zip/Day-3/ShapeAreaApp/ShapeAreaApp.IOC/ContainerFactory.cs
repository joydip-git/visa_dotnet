﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaApp.IOC
{
    public class ContainerFactory
    {
        private static IContainer container;

        public static IContainer CreateContainer()
        {
            if (container == null)
                container = new Container();

            return container;
        }
    }
}
