﻿using ShapeAreaApp.Entities;
using ShapeAreaApp.IOC;
using System;

namespace ShapeAreaApp.UserInterface
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine(ContainerFactory.CreateContainer().CreateShape(ShapeType.Circle, 12).CalculateArea());
        }
    }
}
