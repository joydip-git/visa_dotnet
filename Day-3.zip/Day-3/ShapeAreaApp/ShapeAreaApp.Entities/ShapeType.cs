﻿namespace ShapeAreaApp.Entities
{
    public enum ShapeType
    {
        Circle,
        Triangle,
        Rectangle
    }
}
