﻿namespace ShapeAreaApp.Entities
{
    public class Triangle : IShape
    {
        private double _tBase;
        private double _tHeight;

        public Triangle()
        {

        }
        public Triangle(double tbase, double theight)
        {
            _tBase = tbase;
            _tHeight = theight;
        }

        public double THeight
        {
            get { return _tHeight; }
            set { _tHeight = value; }
        }
        public double TBase
        {
            get { return _tBase; }
            set { _tBase = value; }
        }

        public double CalculateArea()
        {
            return 0.5 * _tBase * _tHeight;
        }
    }
}
