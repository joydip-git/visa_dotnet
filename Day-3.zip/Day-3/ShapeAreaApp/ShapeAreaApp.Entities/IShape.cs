﻿namespace ShapeAreaApp.Entities
{
    public interface IShape
    {
        double CalculateArea();
    }
}
