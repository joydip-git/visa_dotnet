﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    class Student
    {
        public double CalculateAverageandDecideGraceMarks(string name, double passMarks, out double graceMarks, double maxGraceMarks, params double[] marks)
        {
            if (marks != null && marks.Length > 0)
            {
                double sum = 0;
                double average = 0;
                foreach (double mark in marks)
                {
                    sum += mark;
                }
                average = sum / marks.Length;
                if (passMarks - average <= maxGraceMarks)
                    graceMarks = passMarks - average;
                else
                    graceMarks = 0;

                return average;
            }
            else
                graceMarks = 0;

            return 0;
        }
    }
}
