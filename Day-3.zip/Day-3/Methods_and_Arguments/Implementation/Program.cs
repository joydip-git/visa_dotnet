﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation
{
    class Program
    {
        static void Main()
        {
            Student anilStudent = new Student();
            double anilGraceMarks;
            double anilAverageMarks = anilStudent.CalculateAverageandDecideGraceMarks("anil", 40, out anilGraceMarks, 5, 23, 34, 56);
            Console.WriteLine($"anil has average marks {anilAverageMarks} and required grace marks:{anilGraceMarks}");

            Student sunilStudent = new Student();
            double sunilGraceMarks;
            double sunilAverageMarks = sunilStudent.CalculateAverageandDecideGraceMarks("sunil", 40, out sunilGraceMarks, 5, 23, 34, 46);
            Console.WriteLine($"sunil has average marks {sunilAverageMarks} and required grace marks:{sunilGraceMarks}");
        }
    }
}
