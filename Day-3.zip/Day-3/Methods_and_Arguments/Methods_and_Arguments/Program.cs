﻿using System;

namespace Methods_and_Arguments
{
    class Shape
    {
        public static int CalculateArea(int param1)
        {
            return param1;
        }
        public static int CalculateArea(int param1, int param2)
        {
            return (param1 + param2) / 2;
        }
        public static void CalculateArea(int param1, int param2 = default(int), int param3 = default(int), int param4 = default(int), int param5 = default(int), int param6 = default(int))
        {
            if (param1 != default(int))
            {

            }
        }
    }
    class Program
    {
        static void Swap(int a, ref int b, out int c)
        {
            a = 11;
            b = 21;
            //The out parameter 'c' must be assigned to before control leaves the current method
            c = 31;
            Console.WriteLine($"inside method \na={a}, b={b}, c={c}");
        }
        static void Test(int x, params int[] args)
        {

        }
        /*
        static bool TryParseDate(string s, out DateTime date)
        {
            bool possible = false;
            try
            {
                date = DateTime.Parse(s);
                possible = true;
            }
            catch (Exception ex)
            {
                date = DateTime.Today;
            }
            return possible;
        }
        */
        static void Main()
        {
            //int[] arr = new int[] { 12, 13 };
            //Use of unassigned local variable 'm'
            //int m;
            //Console.WriteLine(m);

            //in case of pass by ref or pass by value, parameter (local variable) must be assigned
            int x = 10;
            int y = 20;
            int z = 30;
            //int z;
            Console.WriteLine($"before sending values to method \nx={x}, y={y}, z={z}");
            Swap(x, ref y, out z);
            Console.WriteLine($"after sending values to method \nx={x}, y={y}, z={z}");

            Console.Write("enter date of birth: ");
            string dob = Console.ReadLine();
            DateTime dt;
            bool possible = DateTime.TryParse(dob, out dt);
            if (possible)
                Console.WriteLine(dt);
            else
            {
                Console.WriteLine($"not possible, default value {dt}");
            }

            Shape.CalculateArea(param1: 12);
            Shape.CalculateArea(param1: 12, param2: 13);
            Shape.CalculateArea(param1: 12, param2: 13, param3: 14, param4: 15);

            //Test(x, new int[] { 12, 13 });
            Test(x);
            Test(x, 12, 13);
            Test(x, 12, 13, 14, 15, 16);
        }
    }
}
