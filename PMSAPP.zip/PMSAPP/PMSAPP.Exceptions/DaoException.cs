﻿using System;

namespace PMSAPP.Exceptions
{
    public class DaoException:ApplicationException
    {
        private string _errorMessage;
        private Exception _wrappedException;

        public DaoException()
        {

        }
        public DaoException(string message)
        {
            _errorMessage = message;
        }
        public DaoException(string message, Exception exception)
        {
            _errorMessage = message;
            _wrappedException = exception;
        }
        public override string Message => _errorMessage;
        public Exception WrappedException
        {
            get => _wrappedException;
        }
    }
}
