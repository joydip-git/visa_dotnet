﻿using PMSAPP.DataAccessLayer.Contract;
using PMSAPP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using PMSAPP.Exceptions;

namespace PMSAPP.DataAccessLayer.Implementation
{
    public class ProductDataAccessComponent : IDataAccessComponent<Product>
    {
        public int Delete(int id)
        {
            int recordDeleted = 0;
            try
            {
                return recordDeleted;
            }
            catch (ProductExistsException ex)
            {
                throw WrapAndThrowException(ex);
            }
            catch (NullReferenceException ex)
            {
                throw WrapAndThrowException(ex);
            }
            catch (Exception ex)
            {
               throw WrapAndThrowException(ex);
            }
        }
        public Product Fetch(int id)
        {
            try
            {
                return null;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public List<Product> FetchAll()
        {
            try
            {
                return null;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public int Insert(Product newItem)
        {
            try
            {
                return 0;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        public int Modify(Product newItem)
        {
            try
            {
                return 0;
            }
            catch (Exception ex)
            {
                throw WrapAndThrowException(ex);
            }
        }

        #region Helper Methods
        private static DaoException WrapAndThrowException(Exception ex)
        {
            DaoException daoEx = new DaoException(ex.Message, ex);
            throw daoEx;
        }
        #endregion
    }
}
