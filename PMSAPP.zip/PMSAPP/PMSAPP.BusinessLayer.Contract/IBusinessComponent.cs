﻿using System.Collections.Generic;

namespace PMSAPP.BusinessLayer.Contract
{
    public interface IBusinessComponent<T>
    {
        List<T> GetAll();
        T Get(int id);
        int Add(T newItem);
        int Remove(int id);
        int Update(T newItem);
    }
}
