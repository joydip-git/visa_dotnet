﻿using PMSAPP.BusinessLayer.Contract;
using PMSAPP.DataAccessLayer.Contract;
using PMSAPP.DataAccessLayer.Implementation;
using PMSAPP.Entities;
using PMSAPP.Exceptions;
using System;
using System.Collections.Generic;

namespace PMSAPP.BusinessLayer.Implementation
{
    public class ProductBusinessComponent : IBusinessComponent<Product>
    {
        IDataAccessComponent<Product> dataAccessComponent;

        public int Add(Product newItem)
        {
            try
            {
                dataAccessComponent = new ProductDataAccessComponent(); 
                return dataAccessComponent.Insert(newItem);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Product Get(int id)
        {
            try
            {
                return dataAccessComponent.Fetch(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Product> GetAll()
        {
            try
            {
                return dataAccessComponent.FetchAll();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Remove(int id)
        {
            try
            {
                return dataAccessComponent.Delete(id);
            }
            catch(DaoException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Update(Product newItem)
        {
            try
            {
                return dataAccessComponent.Modify(newItem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
