using System;

namespace MySystem
{
	namespace DataAccess
	{
		public class SqlDataAccess
		{
			public void GetData()
			{
			}
		}
		public class OracleDataAccess
		{
			[Obsolete(""this is depricated...use the new GetDataNew method")]
			public void GetData()
			{
			}
		}
	}
	namespace Drawing
	{
		public class Circle
		{
			public void Draw()
			{
			}
		}
		public class Rectangle
		{
			public void Draw()
			{
			}
		}
	}
	public class MyConsole
	{
		public void Write()
		{
		}
	}
}