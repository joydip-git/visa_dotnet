﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OOPDemo.Logic;

namespace OOPDemo.UserInterface
{
    class Program
    {
        static void Main()
        {
            Student joyStudent = new Student("joy", 1, "DotNet", 56, null);
            joyStudent.Name = "joydip";
            string information = joyStudent.GetInformation();
            Console.WriteLine(information);
            Console.WriteLine(joyStudent.Name);

            Student anilStudent = new Student("anil", 2, "Java", 67, null);
            string anilInfo = anilStudent.GetInformation();
        }
    }
}
