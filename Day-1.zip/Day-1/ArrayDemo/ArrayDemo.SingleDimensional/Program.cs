﻿using System;

namespace ArrayDemo.SingleDimensional
{
    class Program
    {
        static void Main()
        {
            //Array arr = new Array(int,2);
            Console.Write("enter number of elements: ");
            int elements = int.Parse(Console.ReadLine());
            int[] arr = new int[elements];
            //Console.WriteLine(arr.GetType().Name);
            Console.WriteLine("\n");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"enter value at arr[{i}]: ");
                arr[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("\n");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine($"value at arr[{i}]: {arr[i]}");
            }

            string[] names = new string[5];
            string name = "joydip";
            names[0] = name ;
        }
    }
}
