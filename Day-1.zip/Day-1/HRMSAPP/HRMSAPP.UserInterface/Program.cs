﻿using HRMSAPP.Entities;
using HRMSAPP.UserInterface.Utilities;

namespace HRMSAPP.UserInterface
{
    class Program
    {
        static void Main()
        {
            int recordCount = EmployeeUtility.GetCount();
            Employee[] employees = new Employee[recordCount];
            EmployeeUtility.SaveEmployee(recordCount, employees);
            EmployeeUtility.PrintEmployeeSalary(employees);
        }
    }
}
