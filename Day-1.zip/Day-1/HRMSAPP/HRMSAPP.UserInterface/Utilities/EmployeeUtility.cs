﻿using HRMSAPP.Entities;
using System;

namespace HRMSAPP.UserInterface.Utilities
{
    public static class EmployeeUtility
    {
        public static int GetCount()
        {
            Console.Write("How many employee records? ");
            return int.Parse(Console.ReadLine());
        }
        public static Employee CreateEmployee()
        {
            Console.Write("\nName: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Basic Payment: ");
            decimal basicPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Da Payment: ");
            decimal daPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Hra Payment: ");
            decimal hraPayment = decimal.Parse(Console.ReadLine());

            return new Employee(name, id, basicPayment, daPayment, hraPayment);
        }
        public static void SaveEmployee(int recordCount, Employee[] employees)
        {
            for (int i = 0; i < recordCount; i++)
            {
                Console.WriteLine($"\nRecord#{i + 1}");
                Employee employee = CreateEmployee();
                employees[i] = employee;
            }
        }
        public static void PrintEmployeeSalary(Employee[] employees)
        {
            foreach (Employee employee in employees)
            {
                Console.WriteLine($"{employee.Name} has got salary of {employee.CalculateSalary()}");
            }
        }
    }
}
