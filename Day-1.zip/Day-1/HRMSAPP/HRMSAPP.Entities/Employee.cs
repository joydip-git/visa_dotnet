﻿namespace HRMSAPP.Entities
{
    /// <summary>
    /// Employee class
    /// </summary>
    public class Employee
    {
        #region Data Members
        private int id;
        private string name;
        private decimal basicPayment;
        private decimal daPayment;
        private decimal hraPayment;
        #endregion

        #region Constructors
        /// <summary>
        /// default constructor
        /// </summary>
        public Employee()
        {

        }
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="name">name of employee</param>
        /// <param name="id">id of employee</param>
        /// <param name="basicPay">basic payment of employee</param>
        /// <param name="daPay">da payment of employee</param>
        /// <param name="hraPay">hra payment of employee</param>
        public Employee(string name, int id, decimal basicPay, decimal daPay, decimal hraPay)
        {
            this.name = name;
            this.id = id;
            this.basicPayment = basicPay;
            this.daPayment = daPay;
            this.hraPayment = hraPay;
        }
        #endregion

        #region Properties
        /// <summary>
        /// gets or sets the hra payment
        /// </summary>
        public decimal HraPayment
        {
            get { return hraPayment; }
            set { hraPayment = value; }
        }
        /// <summary>
        /// gets or sets the da payment
        /// </summary>
        public decimal DaPayment
        {
            get { return daPayment; }
            set { daPayment = value; }
        }
        /// <summary>
        /// gets or sets the basic payment
        /// </summary>
        public decimal BasicPayment
        {
            get { return basicPayment; }
            set { basicPayment = value; }
        }
        /// <summary>
        /// gets or sets the name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        /// <summary>
        /// gets or sets the id
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Method to calculate total salary of an employee
        /// </summary>
        /// <returns>
        /// returns total calculated salary
        /// </returns>
        public decimal CalculateSalary()
        {
            return this.basicPayment + this.daPayment + this.hraPayment;
        }
        #endregion
    }
}
