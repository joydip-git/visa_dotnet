using System;

namespace MySystem
{
	namespace DataAccess
	{
		public class MongoDbAccess
		{
			public void GetData()
			{
			}
		}
		public class GrpahDbDataAccess
		{
			public void GetData()
			{
			}
		}
		public class OracleDataAccess
		{
			
			public void GetDataNew()
			{
			}
		}
	}
}
