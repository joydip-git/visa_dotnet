using System;

namespace LibraryApp
{
	public class Sample
	{
		public string SayHello(string name)
		{
			return $"hello {name}";
		}
	}
}