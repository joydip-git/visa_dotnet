﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorApp.CalcuationLogic
{
    /// <summary>
    /// Calculation class containing methods
    /// </summary>
    public class Calculation
    {
        /// <summary>
        /// method to add two numbers
        /// </summary>
        /// <param name="x">first number</param>
        /// <param name="y">second number</param>
        /// <returns>an added value</returns>
        public int Add(int x, int y)
        {
            return (x + y);
        }
        /// <summary>
        /// method to subtract two numbers
        /// </summary>
        /// <param name="x">first number</param>
        /// <param name="y">second number</param>
        /// <returns>a subtracted value</returns>
        public int Subtract(int x, int y)
        {
            return (x + y);
        }
        /// <summary>
        /// method multiply add two numbers
        /// </summary>
        /// <param name="x">first number</param>
        /// <param name="y">second number</param>
        /// <returns>multiplication value</returns>
        public int Multiply(int x, int y)
        {
            return (x + y);
        }
        /// <summary>
        /// method to divide two numbers
        /// </summary>
        /// <param name="x">first number</param>
        /// <param name="y">second number</param>
        /// <returns>division value</returns>
        public int Divide(int x, int y)
        {
            return (x + y);
        }
    }
}
