﻿using CalculatorApp.CalcuationLogic;
using System;

namespace CalculatorApp.UserInterface
{
    class Program
    {
        static void Main()
        {
            Calculation calculation = new Calculation();
            int resultAdd = calculation.Add(12, 13);
            Console.WriteLine($"add result: {resultAdd}");

            Console.WriteLine("press enter any key to terminarte...");
            Console.ReadLine();
        }
    }
}
