using System; //mscorlib.dll
using LibraryApp; //SecondApp.dll

using MySystem;
using MySystem.DataAccess;

namespace ClientApp
{
	class Program
	{
		public static void Main()
		{
			Console.WriteLine("hello guys...");
			Sample sampleObj = new Sample();
			string result = sampleObj.SayHello("joydip");
			Console.WriteLine(result);

			MyConsole mc = new MyConsole();
			mc.Write();

			SqlDataAccess data = new SqlDataAccess();
			data.GetData();

			MongoDbAccess data1 = new MongoDbAccess();
			data1.GetData();
		}
	}

	class A
	{
		static void Main()
		{
			Console.WriteLine("another main...");
			Program.Main();
		}
	}
}