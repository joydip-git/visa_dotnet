﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VISA.DOTNET.LMSAPP.Entities;
using VISA.DOTNET.LMSAPP.DataAcessLayer;

namespace VISA.DOTNET.LMSAPP.BusinessLayer
{
    public class MemberBusinesComponent
    {
        MemberDataAccessComponent memberDao;
        public LibraryMember AuthenticateMember(string userId, string password)
        {
            memberDao = new MemberDataAccessComponent();
            return memberDao.Authenticate(userId, password);
        }
    }
}
