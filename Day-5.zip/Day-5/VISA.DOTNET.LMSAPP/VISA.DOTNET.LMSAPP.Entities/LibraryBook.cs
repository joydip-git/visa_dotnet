﻿using System;

namespace VISA.DOTNET.LMSAPP.Entities
{
    public class LibraryBook:IComparable, IComparable<LibraryBook>
    {
        public string BookName { get; set; }
        public int BookId { get; set; }
        public string BookAuthorName { get; set; }
        public decimal Price { get; set; }

        public LibraryBook()
        {

        }

        public LibraryBook(string bookName, int bookId, string bookAuthorName, decimal price)
        {
            this.BookAuthorName = bookAuthorName;
            this.BookId = bookId;
            this.BookName = bookName;
            this.Price = price;
        }
        public override int GetHashCode()
        {
            return this.BookId.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                if (obj is LibraryBook)
                {
                    LibraryBook other = obj as LibraryBook;
                    if (this == other)
                        return true;

                    if (!this.BookId.Equals(other.BookId))
                        return false;

                    if (!this.BookName.Equals(other.BookName))
                        return false;

                    if (!this.BookAuthorName.Equals(other.BookAuthorName))
                        return false;

                    if (!this.Price.Equals(other.Price))
                        return false;

                    return true;
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to Equals method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to Equals method");
        }

        public override string ToString()
        {
            return $"Name={this.BookName},Id={this.BookId}, Author = {this.BookAuthorName} and Price = {this.Price}";
        }

        public int CompareTo(object obj)
        {
            if (obj != null)
            {
                if (obj is LibraryBook)
                {
                    LibraryBook other = obj as LibraryBook;
                    if (this == other)
                        return 0;

                    return this.BookId.CompareTo(other.BookId);
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }

        public int CompareTo(LibraryBook other)
        {
            if (other != null)
            {
                if (this == other)
                    return 0;

                return this.BookId.CompareTo(other.BookId);
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }
    }
}
