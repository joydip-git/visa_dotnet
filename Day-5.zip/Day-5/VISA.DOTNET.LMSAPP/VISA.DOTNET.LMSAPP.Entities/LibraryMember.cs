﻿using System;

namespace VISA.DOTNET.LMSAPP.Entities
{
    public class LibraryMember : IComparable, IComparable<LibraryMember>
    {
        public string Name { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public LibraryMember()
        {

        }
        public LibraryMember(string userId = null, string password = null, string name = null)
        {
            this.UserId = userId;
            this.Password = password;
            this.Name = name;
        }
        public override int GetHashCode()
        {
            const int prime = 31;
            return this.UserId == null ? prime : this.UserId.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                if (obj is LibraryMember)
                {
                    LibraryMember other = obj as LibraryMember;
                    if (this == other)
                        return true;

                    if (!this.Name.Equals(other.Name))
                        return false;

                    if (!this.UserId.Equals(other.UserId))
                        return false;

                    if (!this.Password.Equals(other.Password))
                        return false;

                    return true;
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to Equals method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to Equals method");
        }
        public override string ToString()
        {
            return $"Name={this.Name}, UserId={this.UserId} and Password={this.Password}";
        }

        public int CompareTo(object obj)
        {
            if (obj != null)
            {
                if (obj is LibraryMember)
                {
                    LibraryMember other = obj as LibraryMember;
                    if (this == other)
                        return 0;

                    return this.UserId.CompareTo(other.UserId);
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }

        public int CompareTo(LibraryMember other)
        {
            if (other != null)
            {
                if (this == other)
                    return 0;

                return this.UserId.CompareTo(other.UserId);
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }
    }
}
