﻿using System;

namespace VISA.DOTNET.LMSAPP.Entities
{
    public sealed class MemberBookCatalog : IComparable, IComparable<MemberBookCatalog>
    {
        private DateTime issuedDate;
        public int EntryId { get; set; }
        public LibraryBook BookInformation { get; set; }
        public LibraryMember MemberInformation { get; set; }
        public DateTime IssuedDate
        {
            get => issuedDate;
            private set
            {
                if (this.issuedDate != DateTime.Now)
                    this.issuedDate = DateTime.Now;
                this.ExpectedReturnDate = this.issuedDate.AddDays(7);
            }
        }
        public DateTime ExpectedReturnDate { get; private set; }
        //public Nullable<DateTime> ActualReturnDate { get; set; }
        public DateTime? ActualReturnDate { get; set; }

        //public MemberBookCatalog()
        //{

        //}
        public MemberBookCatalog(LibraryBook bookDetails, LibraryMember memberDetails)
        {
            this.BookInformation = bookDetails;
            this.MemberInformation = memberDetails;
            this.IssuedDate = DateTime.Now;
        }
        public override int GetHashCode()
        {
            return this.EntryId.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                if (obj is LibraryBook)
                {
                    MemberBookCatalog other = obj as MemberBookCatalog;
                    if (this == other)
                        return true;

                    if (!this.EntryId.Equals(other.EntryId))
                        return false;

                    if (!this.BookInformation.Equals(other.BookInformation))
                        return false;

                    if (!this.MemberInformation.Equals(other.MemberInformation))
                        return false;

                    if (!this.IssuedDate.Equals(other.IssuedDate))
                        return false;

                    if (!this.ExpectedReturnDate.Equals(other.ExpectedReturnDate))
                        return false;

                    if (this.ActualReturnDate.HasValue)
                        if (!this.ActualReturnDate.Value.Equals(other.ActualReturnDate.Value))
                            return false;

                    return true;
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to Equals method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to Equals method");
        }
        public override string ToString()
        {
            return $"Book Name = {this.BookInformation.BookName} book ,Member Name={this.MemberInformation.Name}, BorrowedDate = {this.issuedDate.Date}, Expected Return Date:{this.ExpectedReturnDate} and Actual Return Date: {(this.ActualReturnDate.HasValue ? this.ActualReturnDate.Value.ToShortDateString() : "book not returned yet")}";
        }

        public int CompareTo(object obj)
        {
            if (obj != null)
            {
                if (obj is MemberBookCatalog)
                {
                    MemberBookCatalog other = obj as MemberBookCatalog;
                    if (this == other)
                        return 0;

                    return this.EntryId.CompareTo(other.EntryId);
                }
                else
                    throw new ArgumentException($"reference of {obj.GetType().Name} type instance was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }

        public int CompareTo(MemberBookCatalog other)
        {
            if (other != null)
            {
                if (this == other)
                    return 0;

                return this.EntryId.CompareTo(other.EntryId);
            }
            else
                throw new NullReferenceException($"null reference was passed instead of a {this.GetType().Name} instance reference to CompareTo method");
        }
    }
}
