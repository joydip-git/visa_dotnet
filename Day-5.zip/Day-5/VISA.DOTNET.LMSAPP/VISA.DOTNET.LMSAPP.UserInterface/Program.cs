﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VISA.DOTNET.LMSAPP.Entities;
using VISA.DOTNET.LMSAPP.BusinessLayer;
using System.Diagnostics;

namespace VISA.DOTNET.LMSAPP.UserInterface
{
    class Program
    {
        static void Main()
        {
            char toContinue = 'n';
            do
            {
                ShowMainMenu();
                int mainChoice = GetMainMenuChoice();

                LibraryMember memberInSession = null;
                MemberBusinesComponent businessComponent = new MemberBusinesComponent();

                switch (mainChoice)
                {
                    case 1:
                        memberInSession = LogIn(businessComponent);
                        if (memberInSession != null)
                        {
                            ShowBookMenu();
                            int operationChoice = GetBookMenuChoice();
                            switch (operationChoice)
                            {
                                case 1:

                                    break;

                                case 2:
                                    break;

                                default:
                                    break;
                            }
                        }
                        else
                            Console.WriteLine("\nInvalid member");
                        break;

                    case 2:
                        if (memberInSession != null)
                            memberInSession = null;
                        break;

                    case 3:
                        Exit();
                        break;

                    default:
                        break;
                }

                DecideToContinue(ref toContinue);
            } while (toContinue != 'n' && toContinue == 'y');
        }
        private static int GetBookMenuChoice()
        {
            Console.Write("\nenter choice[1/2]: ");
            return int.Parse(Console.ReadLine());
        }
        private static void ShowBookMenu()
        {
            Console.WriteLine("\n1. Borrow a book");
            Console.WriteLine("2. Return a book");
        }

        private static void DecideToContinue(ref char toContinue)
        {
            Console.Write("\nWould you like to continue?[enter y for Yes and n for No");
            toContinue = char.Parse(Console.ReadLine());
            toContinue = char.IsLower(toContinue) ? toContinue : char.ToLower(toContinue);
        }

        private static LibraryMember LogIn(MemberBusinesComponent businessComponent)
        {
            LibraryMember memberInSession;
            Console.Write("\nUser Name: ");
            string userId = Console.ReadLine();
            Console.Write("Password: ");
            string password = Console.ReadLine();
            memberInSession = businessComponent.AuthenticateMember(userId, password);
            return memberInSession;
        }

        private static void Exit()
        {
            Console.Write("\nWould you like to exit?[enter y for Yes and n for No]: ");
            char exitOrNot = char.ToLower(char.Parse(Console.ReadLine()));
            if (exitOrNot == 'y')
                Process.GetCurrentProcess().Kill();
        }
        private static int GetMainMenuChoice()
        {
            Console.Write("\nenter choice[1/2/3]: ");
            return int.Parse(Console.ReadLine());
        }
        private static void ShowMainMenu()
        {
            Console.WriteLine("\n1. Login");
            Console.WriteLine("2. Logout");
            Console.WriteLine("3. Exit");
        }
    }
}
