﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VISA.DOTNET.LMSAPP.Entities;

namespace VISA.DOTNET.LMSAPP.DataAcessLayer
{
    public class BookDataAccessComponent
    {
        public List<LibraryBook> GetBooks()
        {
            return null;
        }
        public LibraryBook GetBookByBookId(int bookId)
        {
            return null;
        }
        public bool BorrowBook()
        {
            return false;
        }
        public List<LibraryBook> GetBooksByMemberId(string memberUserId)
        {
            return null;
        }   
        public bool RetunBook()
        {
            return false;
        }
    }
}
