﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VISA.DOTNET.LMSAPP.Entities;

namespace VISA.DOTNET.LMSAPP.DataAcessLayer
{
    public class MemberDataAccessComponent
    {
        public LibraryMember Authenticate(string userName, string password)
        {
            return null;
        }
    }
}
