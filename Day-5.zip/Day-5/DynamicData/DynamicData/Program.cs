﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace DynamicData
{
    class Message
    {

    }
    class DeliveryPerson
    {

    }
    class Order
    {

    }
    class Customer
    {
        public string name = "joydip";
    }
    class Program
    {
        static Message CreateMessage()
        {
            dynamic message = new Message();
            //message.DeliveryPerson = new DeliveryPerson();
            //message.OrderDetails = new Order();
            message.Customer = new Customer();
            return message;
        }
        static void Main(string[] args)
        {
            //PrintMessage(CreateMessage());
            string jsonData = JsonConvert.SerializeObject(new { FirstName = "anil", LastName = "gupta" });
            Console.WriteLine(jsonData);
            dynamic obj = JsonConvert.DeserializeObject(jsonData);
            Console.WriteLine(obj.FirstName+" "+obj.LastName);
        }

        private static void PrintMessage(dynamic message)
        {
            Console.WriteLine(message.Customer.name);
        }
    }
}
