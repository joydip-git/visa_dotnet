﻿using System;
using System.Collections.Generic;

namespace DelegateDemo
{
    delegate void Invoker(string data = null, string message = null);
    class DataAccess
    {
        public void GetData(Invoker invoker)
        {
            string data = "data";
            if (data != null)
                invoker(data, null);
            else
                invoker(null, "sorry");
        }
    }
    class Program
    {
        static void Test()
        {

        }
        static void OnCompletion(string data = null, string errorMessage = null)
        {
            if (data != null)
                Console.WriteLine(data);

            if (errorMessage != null)
                Console.WriteLine(errorMessage);
        }
        static void Main()
        {
            /*
            Assistant ramesh = new Assistant { Name = "Ramesh" };
            Trainer trainer = new Trainer { Name = "Joydip", Assistant = ramesh };

            Facilities facilities = new Facilities();
            FacilityInvoker invoker = new FacilityInvoker(facilities.GetRemote);
            Console.WriteLine(trainer.GetHelp(invoker, 2));
            */

            DataAccess dataAccess = new DataAccess();
            dataAccess.GetData(new Invoker(OnCompletion));
            Test();
        }
    }
}
