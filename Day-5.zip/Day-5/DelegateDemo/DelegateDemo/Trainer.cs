﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Trainer
    {
        public string Name { get; set; }
        public Assistant Assistant { get; set; }
        public Trainer()
        {

        }
        public Trainer(string name, Assistant assistant)
        {
            this.Name = name;
            this.Assistant = assistant;
        }
        public string GetHelp(FacilityInvoker facilityToInvoke, params object[] args)
        {
           return this.Assistant.HelpTrainer(facilityToInvoke, args[0]);
        }
    }
}
