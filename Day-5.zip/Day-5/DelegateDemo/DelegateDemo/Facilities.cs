﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    delegate string FacilityInvoker(int count);
    class Facilities
    {
        public string GetMarker(int count)
        {
            return $"providing {count} markers";
        }
        public string GetRemote(int count)
        {
            return $"providing {count} remotes";
        }
    }
}
