﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Assistant
    {
        public string Name { get; set; }
        public string HelpTrainer(FacilityInvoker facilityToInvoke, params object[] args)
        {
           return facilityToInvoke((int)args[0]);
        }
    }
}
