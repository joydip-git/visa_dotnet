﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    //1.
    delegate void CalDel(int a, int b);
    /*
    sealed class CalDel : MulticastDelegate:Delegate:Object
    {
        MethodInfo _method;
        object _target;
        Delegate[] _invocationList;
        public void Invoke(int a, int b)
        {

        }
        public Delegate[] GetInvocationList()
        {
          return _invocationList;
        }
        public static operator +()
        {
           _invocationList = new Delegate[]{};
        }

    }
    */
    class Calculation
    {
        public static void Add(int x, int y)
        {
            Console.WriteLine(x + y);
        }
        public void Multiply(int x, int y)
        {
            Console.WriteLine(x * y);
        }
    }
    class Program
    {
        static void Main()
        {
            //2. referring a function by delegate
            //CalDel cd1 = new CalDel(Calculation.Add);
            //CalDel cd2 = new CalDel(new Calculation().Multiply);

            CalDel cd1 = Calculation.Add;
            //CalDel cd2 = new Calculation().Multiply;

            CalDel cd = Calculation.Add;
            cd += new Calculation().Multiply;
            //int res = cd(12, 13);

            //3. invoke that function using that delegate
            //cd1.Invoke(12, 13);
            //cd2(12, 13);
            //cd(12, 13);
            Delegate[] allRefs = cd.GetInvocationList();
            foreach (Delegate item in allRefs)
            {
                Console.Write("1st: ");
                string f = Console.ReadLine();
                Console.Write("2nd: ");
                string s = Console.ReadLine();
                (item as CalDel).Invoke(int.Parse(f), int.Parse(s));
            }
            Console.WriteLine("\n");
            IAsyncResult op = cd1.BeginInvoke(12, 13, null, null);
            if (op.IsCompleted)
            {
                cd1.EndInvoke(op);
            }
        }
    }
}
