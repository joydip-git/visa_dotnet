﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace KeyValueCollections
{
    class Program
    {
        static void Main()
        {
            Hashtable hashtable = new Hashtable();
            hashtable.Add(1, "visa");
            hashtable.Add("abcd", 12.34);
            hashtable["xyz"] = 'a';

            foreach (DictionaryEntry item in hashtable)
            {
                Console.WriteLine($"{item.Key}:{item.Value}");
            }

            Console.WriteLine("\nvalues from sorted list\n");

            SortedList sortedList = new SortedList();
            sortedList.Add("abcd", 12.34);
            sortedList.Add("1", "visa");
            sortedList["xyz"] = 'a';

            foreach (DictionaryEntry item in sortedList)
            {
                Console.WriteLine($"{item.Key}:{item.Value}");
            }

            Console.WriteLine("\nvalues from dictionary\n");

            Dictionary<int, string> keyValuePairs = new Dictionary<int, string>();
            keyValuePairs.Add(2, "abcd");
            keyValuePairs.Add(0, "xyz");
            keyValuePairs.Add(1, "mnop");
            foreach (KeyValuePair<int, string> item in keyValuePairs)
            {
                Console.WriteLine($"{item.Key}:{item.Value}");
            }

            Console.WriteLine("\nvalues from sl generic\n");

            SortedList<int, string> slGeneric = new SortedList<int, string>();
            slGeneric.Add(2, "abcd");
            slGeneric.Add(0, "xyz");
            slGeneric.Add(1, "mnop");
            foreach (KeyValuePair<int, string> item in slGeneric)
            {
                Console.WriteLine($"{item.Key}:{item.Value}");
            }

            List<int> list = new List<int> { 1, 2, 3, 4, 5 };
            IEnumerator<int> enumerator = list.GetEnumerator();
            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }
        }
    }
}
