﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CustomCollectionDemo
{
    public interface ICollectionOperations<T>
    {
        void Add(T item);
        T Remove(T item);
        int Count { get; }
        int Capacity { get; }
        T this[int index] { get; set; }
    }
    public class MyList<T> : ICollectionOperations<T>, IEnumerable<T>
    {
        T[] items;
        int positionIndex;

        public MyList()
        {
            items = new T[4];
        }

        public int Count
        {
            get
            {
                return positionIndex;
            }
        }

        public int Capacity => items.Length;

        public void Add(T item)
        {
            if (positionIndex == items.Length)
            {
                T[] temp = items;
                items = new T[items.Length * 2];
                temp.CopyTo(items, 0);
            }

            items[positionIndex] = item;
            positionIndex++;
        }

        public T Remove(T item)
        {
            return default(T);
        }

        public IEnumerator<T> GetEnumerator()
        {
            //for (int i = 0; i < this.Count; i++)
            //{
            //    yield return items[i];
            //}
            foreach (T item in items)
            {
                if (!item.Equals(default(T)))
                    yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        //Indexer
        public T this[int index]
        {
            set { items[index] = value; positionIndex++; }
            get { return items[index]; }
        }
    }
}
