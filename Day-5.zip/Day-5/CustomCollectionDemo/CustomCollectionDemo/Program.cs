﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomCollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            MyList<int> list = new MyList<int>();
            list.Add(12);
            list.Add(12);
            list.Add(12);
            list.Add(12);
            list.Add(12);
            list[5] = 13;
            //list[5] = 13;
            //list[5] = 13;

            Console.WriteLine("through for loop [indexer]\n");

            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
            Console.WriteLine("\nthrough foreach loop [enumerator]\n");
            foreach (int item in list)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("through enumerator\n");
            IEnumerator<int> enumerator = list.GetEnumerator();
            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }
        }
    }
}
