﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace SetDemo
{
    class Program
    {
        static void Main()
        {
           

            Person p1 = new Person { FirstName = "anil", LastName = "gupta" };
            //Person p2 = p1;
            //Person p2 = new Person { FirstName = "sunil", LastName = "mishra" };
            Person p2 = new Person { FirstName = "anil", LastName = "gupta" };

            //bool sameOrNot = p1.Equals(p2);
            //Console.WriteLine(sameOrNot);

            int p1Hash = p1.GetHashCode();
            int p2Hash = p2.GetHashCode();

            if(p1Hash == p2Hash)
            {
                Console.WriteLine("same");
            }
            else
                Console.WriteLine("not same");

            HashSet<Person> peopleSet = new HashSet<Person>();
            peopleSet.Add(p1);            
            peopleSet.Add(p2);
            foreach (Person p in peopleSet)
            {
                Console.WriteLine(p);
            }            
        }
    }
}
