﻿using System;

namespace SetDemo
{
    public class Person : IComparable, IComparable<Person>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Person()
        {

        }
        public Person(string firstName, string lastName)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
        }
        public override string ToString()
        {
            return $"Full Name: {this.FirstName} {this.LastName}";
        }
        public override int GetHashCode()
        {
            const int prime = 23;
            int hash = 0;
            hash = this.FirstName != null ? this.FirstName.GetHashCode() * prime : prime;
            hash = this.LastName != null ? this.LastName.GetHashCode() * hash : hash * prime;
            return hash;
        }
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                if (obj is Person)
                {
                    Person other = obj as Person;
                    if (this == other)
                        return true;

                    if (!this.FirstName.Equals(other.FirstName))
                        return false;
                    if (!this.LastName.Equals(other.LastName))
                        return false;

                    return true;
                }
                else
                    throw new ArgumentException("Type of person reference was not passed to Equals method");
            }
            else
                throw new NullReferenceException("null reference was passed to Equals method");
        }
        public bool Equals(Person other)
        {
            if (other != null)
            {
                if (this == other)
                    return true;

                if (!this.FirstName.Equals(other.FirstName))
                    return false;
                if (!this.LastName.Equals(other.LastName))
                    return false;

                return true;
            }
            else
                throw new NullReferenceException("null reference was passed to Equals method");
        }

        public int CompareTo(object obj)
        {
            return 0;
        }

        public int CompareTo(Person other)
        {
            return 0;
        }
    }
}
